/**
 * One-time setup script: creates the "Thatamarketing Order Assistant" ElevenLabs
 * Conversational AI agent and prints its Agent ID.
 *
 * This script uses your SECRET ElevenLabs API key and is meant to be run ONCE,
 * locally, from your own machine — it is never imported by the website and is
 * never bundled into the browser code.
 *
 * Setup:
 *   1. npm install            (installs @elevenlabs/elevenlabs-js + dotenv)
 *   2. Create a file named ".env" in the project root (it's already gitignored)
 *      containing one line:
 *        ELEVENLABS_API_KEY=your_rotated_secret_key_here
 *   3. Run:  node scripts/create-elevenlabs-agent.mjs
 *   4. Copy the printed Agent ID into ELEVENLABS_AGENT_ID in src/App.tsx
 *   5. In the ElevenLabs dashboard, open the new agent and:
 *      a. Tools -> Add Tool -> Tool Type "Client" -> name it exactly
 *         "fill_order_form" with parameters: customer_name (string),
 *         mobile_number (string), delivery_address (string), notes (string,
 *         optional), items (array of {product_id: string, quantity: number}).
 *         Tick "Wait for response".
 *      b. Advanced tab -> make sure authentication is NOT required (the
 *         website connects with just the public Agent ID, the same way the
 *         old Vapi assistant ID worked).
 */
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";
import "dotenv/config";

if (!process.env.ELEVENLABS_API_KEY) {
  console.error(
    "Missing ELEVENLABS_API_KEY. Put it in a local .env file (see comment at top of this script)."
  );
  process.exit(1);
}

const elevenlabs = new ElevenLabsClient();

const SYSTEM_PROMPT = `You are the voice ordering assistant for Thatamarketing, a sand, gravel, and construction supplies company.

Help callers figure out what materials they need and where to deliver them, then fill out their order using the fill_order_form tool.

Product catalog: product IDs match the PRODUCTS array on the website. Categories include
aggregates, cement, steel, lumber, roofing, masonry, plumbing, electrical, paint, tiles, doors,
fasteners, waterproofing, tools, safety, hardware, and landscaping.
Example product IDs: sand_washed, portland, rebar_10, coco_lumber, longspan, brick, pvc_pipe,
elec_wire, primer, ceramic_tile, steel_door, common_nail, sil_sealant, shovel, hard_hat, padlock, topsoil.

Collect, naturally through conversation: the customer's name, mobile number, delivery address,
the materials and quantities they want, and any delivery notes. Once you have enough information,
call fill_order_form with: customer_name, mobile_number, delivery_address, notes, and items
(an array of { product_id, quantity }). Confirm the order back to the caller after the form is filled.`;

const agent = await elevenlabs.conversationalAi.agents.create({
  name: "Thatamarketing Order Assistant",
  conversationConfig: {
    agent: {
      firstMessage: "Hi! Thanks for calling Thatamarketing. What materials can I get for you today?",
      language: "en",
      prompt: {
        prompt: SYSTEM_PROMPT,
      },
    },
  },
});

console.log("\nAgent created!");
console.log("Agent ID:", agent.agentId);
console.log("\nNext steps:");
console.log("1. Paste this Agent ID into ELEVENLABS_AGENT_ID in src/App.tsx");
console.log("2. Add the 'fill_order_form' client tool to this agent in the ElevenLabs dashboard (see comment at top of this file)");
console.log("3. In the agent's Advanced tab, confirm authentication is disabled so the public Agent ID can be used directly from the browser");
