/**
 * ElevenLabs Agent Instructions:
 * The full product catalog is now available. Product IDs should match the new PRODUCTS array IDs:
 * categories: 'aggregates', 'cement', 'steel', 'lumber', 'roofing', 'masonry', 'plumbing', 'electrical', 'paint', 'tiles', 'doors', 'fasteners', 'waterproofing', 'tools', 'safety', 'hardware', 'landscaping'
 * Examples: 'sand_washed', 'portland', 'rebar_10', 'coco_lumber', 'longspan', 'brick', 'pvc_pipe', 'elec_wire', 'primer', 'ceramic_tile', 'steel_door', 'common_nail', 'sil_sealant', 'shovel', 'hard_hat', 'padlock', 'topsoil'
 * (These instructions are intended to be pasted into the agent's system prompt in the ElevenLabs
 * dashboard / create-agent script — see scripts/create-elevenlabs-agent.mjs)
 */
import React, { useState, useEffect, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Truck,
  Mountain,
  Layers,
  Clock,
  MapPin,
  ArrowUpRight,
  Play,
  X,
  Check,
  Phone,
  Mail,
  Building,
  Info
} from "lucide-react";
import FadingVideo from "./components/FadingVideo";
import BlurText from "./components/BlurText";
import { Conversation } from "@elevenlabs/client";

// Suppress Framer Motion benign warnings
if (typeof window !== "undefined") {
  const originalError = console.error;
  console.error = (...args) => {
    if (args[0] && typeof args[0] === 'string' && args[0].includes('Framer Motion')) return;
    originalError(...args);
  };
}

// Global configuration
const DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1519694204249571430/vPlQ-cCmhKQeICFGF9SujCz9n4LyWI71qgFIY-YLKwfDy38X2N9fnn7wy6tZfRcO6f0P";
const TURNSTILE_SITEKEY   = "0x4AAAAAADq9nYu9eDBVm_Vd"; // User specified sitekey

// Your ElevenLabs Agent ID (NOT your secret API key — this is safe to expose client-side,
// the same way the old Vapi assistant ID was). Get it by running
// `node scripts/create-elevenlabs-agent.mjs` (see README) or from the agent's page in the
// ElevenLabs dashboard, then paste it in here.
const ELEVENLABS_AGENT_ID = "REPLACE_WITH_YOUR_ELEVENLABS_AGENT_ID";

const BG_VIDEO_URL = "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260419_065931_e3ca7b53-d32e-4ad5-81de-dc9d6fcfda6d.mp4";
const AGGREGATE_VIDEO_URL = "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260622_204103_f607742e-09da-4cf5-bb06-4e67b0a531de.mp4";

const MATERIAL_PRICES: Record<string, number> = {
  "Washed Sand": 45,
  "Fill Sand": 35,
  "Masonry Sand": 52,
  "3/4\" Clean Stone": 58,
  "Pea Gravel": 60,
  "Road Base": 42,
  "Decorative Stone": 75,
};

interface Product {
  id: string;
  category: string;
  name: string;
  unit: string;
  icon?: string;
}

const CATEGORIES = [
  { id: 'aggregates',    label: 'Aggregates',             icon: '🪨' },
  { id: 'cement',        label: 'Cement & Concrete',      icon: '🏗️' },
  { id: 'steel',         label: 'Steel & Reinforcement',  icon: '🔩' },
  { id: 'lumber',        label: 'Lumber & Wood',          icon: '🪵' },
  { id: 'roofing',       label: 'Roofing',                icon: '🏠' },
  { id: 'masonry',       label: 'Hollow Blocks',          icon: '🧱' },
  { id: 'plumbing',      label: 'Pipes & Plumbing',       icon: '🚰' },
  { id: 'electrical',    label: 'Electrical',             icon: '⚡' },
  { id: 'paint',         label: 'Paint & Finishing',      icon: '🎨' },
  { id: 'tiles',         label: 'Tiles & Flooring',       icon: '🏡' },
  { id: 'doors',         label: 'Doors & Windows',        icon: '🚪' },
  { id: 'fasteners',     label: 'Fasteners',              icon: '🔧' },
  { id: 'waterproofing', label: 'Waterproofing',          icon: '💧' },
  { id: 'tools',         label: 'Tools',                  icon: '🛠️' },
  { id: 'safety',        label: 'Safety Equipment',       icon: '🦺' },
  { id: 'hardware',      label: 'Hardware',               icon: '⚙️' },
  { id: 'landscaping',   label: 'Landscaping',            icon: '🌿' },
];

const PRODUCTS: Product[] = [
  // --- Aggregates ---
  { id: 'sand_washed',    category: 'aggregates',    name: 'Washed Sand',        unit: 'cu.m.' },
  { id: 'sand_river',     category: 'aggregates',    name: 'River Sand',         unit: 'cu.m.' },
  { id: 'sand_fine',      category: 'aggregates',    name: 'Fine Sand',          unit: 'cu.m.' },
  { id: 'sand_coarse',    category: 'aggregates',    name: 'Coarse Sand',        unit: 'cu.m.' },
  { id: 'sand_fill',      category: 'aggregates',    name: 'Filling Sand',       unit: 'cu.m.' },
  { id: 'gravel_38',      category: 'aggregates',    name: '3/8 Gravel',         unit: 'cu.m.' },
  { id: 'gravel_34',      category: 'aggregates',    name: '3/4 Gravel',         unit: 'cu.m.' },
  { id: 'gravel_112',     category: 'aggregates',    name: '1 1/2 Gravel',       unit: 'cu.m.' },
  { id: 'gravel_g1',      category: 'aggregates',    name: 'G1 Gravel',          unit: 'cu.m.' },
  { id: 'gravel_g2',      category: 'aggregates',    name: 'G2 Gravel',          unit: 'cu.m.' },
  { id: 'crushed_stone',  category: 'aggregates',    name: 'Crushed Stone',      unit: 'cu.m.' },
  { id: 'base_course',    category: 'aggregates',    name: 'Base Course',        unit: 'cu.m.' },
  { id: 'boulder',        category: 'aggregates',    name: 'Boulder',            unit: 'cu.m.' },
  { id: 'earthfill',      category: 'aggregates',    name: 'Earthfill',          unit: 'cu.m.' },
  { id: 'quarry_dust',    category: 'aggregates',    name: 'Quarry Dust',        unit: 'cu.m.' },
  { id: 'screenings',     category: 'aggregates',    name: 'Screenings',         unit: 'cu.m.' },
  { id: 'agg_s1',         category: 'aggregates',    name: 'S1 Aggregate',       unit: 'cu.m.' },
  { id: 'mixed_agg',      category: 'aggregates',    name: 'Mixed Aggregates',   unit: 'cu.m.' },

  // --- Cement & Concrete ---
  { id: 'portland',       category: 'cement',        name: 'Portland Cement',    unit: 'bags (40kg)' },
  { id: 'masonry_cem',    category: 'cement',        name: 'Masonry Cement',     unit: 'bags (40kg)' },
  { id: 'white_cem',      category: 'cement',        name: 'White Cement',       unit: 'bags (40kg)' },
  { id: 'ready_mix',      category: 'cement',        name: 'Ready-Mix Concrete', unit: 'cu.m.' },
  { id: 'chb4',           category: 'cement',        name: 'CHB 4"',             unit: 'pcs' },
  { id: 'chb5',           category: 'cement',        name: 'CHB 5"',             unit: 'pcs' },
  { id: 'chb6',           category: 'cement',        name: 'CHB 6"',             unit: 'pcs' },
  { id: 'conc_pavers',    category: 'cement',        name: 'Concrete Pavers',    unit: 'pcs' },
  { id: 'conc_pipes',     category: 'cement',        name: 'Concrete Pipes',     unit: 'pcs' },
  { id: 'culvert',        category: 'cement',        name: 'Culvert',            unit: 'pcs' },
  { id: 'precast',        category: 'cement',        name: 'Precast Concrete',   unit: 'pcs' },
  { id: 'conc_post',      category: 'cement',        name: 'Concrete Post',      unit: 'pcs' },
  { id: 'conc_mold',      category: 'cement',        name: 'Concrete Moldings',  unit: 'pcs' },
  { id: 'baluster',       category: 'cement',        name: 'Baluster',           unit: 'pcs' },
  { id: 'premix',         category: 'cement',        name: 'Premix',             unit: 'bags (40kg)' },

  // --- Steel & Reinforcement ---
  { id: 'rebar_10',       category: 'steel',         name: 'Deformed Bar 10mm',  unit: 'lengths (6m)' },
  { id: 'rebar_12',       category: 'steel',         name: 'Deformed Bar 12mm',  unit: 'lengths (6m)' },
  { id: 'rebar_16',       category: 'steel',         name: 'Deformed Bar 16mm',  unit: 'lengths (6m)' },
  { id: 'rebar_20',       category: 'steel',         name: 'Deformed Bar 20mm',  unit: 'lengths (6m)' },
  { id: 'round_bar',      category: 'steel',         name: 'Round Bar',          unit: 'lengths (6m)' },
  { id: 'tie_wire',       category: 'steel',         name: 'Tie Wire',           unit: 'rolls' },
  { id: 'wwm',            category: 'steel',         name: 'Welded Wire Mesh',   unit: 'sheets' },
  { id: 'gi_wire',        category: 'steel',         name: 'GI Wire',            unit: 'rolls' },
  { id: 'angle_bar',      category: 'steel',         name: 'Steel Angle Bar',    unit: 'lengths (6m)' },
  { id: 'flat_bar',       category: 'steel',         name: 'Flat Bar',           unit: 'lengths (6m)' },
  { id: 'square_bar',     category: 'steel',         name: 'Square Bar',         unit: 'lengths (6m)' },
  { id: 'i_beam',         category: 'steel',         name: 'I-Beam',             unit: 'lengths (6m)' },
  { id: 'h_beam',         category: 'steel',         name: 'H-Beam',             unit: 'lengths (6m)' },
  { id: 'c_purlin',       category: 'steel',         name: 'C-Purlin',           unit: 'lengths (6m)' },
  { id: 'u_channel',      category: 'steel',         name: 'U-Channel',          unit: 'lengths (6m)' },
  { id: 'steel_plate',    category: 'steel',         name: 'Steel Plate',        unit: 'sheets' },
  { id: 'exp_metal',      category: 'steel',         name: 'Expanded Metal',     unit: 'sheets' },

  // --- Lumber & Wood ---
  { id: 'coco_lumber',    category: 'lumber',        name: 'Coco Lumber',        unit: 'bd.ft.' },
  { id: 'good_lumber',    category: 'lumber',        name: 'Good Lumber',        unit: 'bd.ft.' },
  { id: 'marine_ply',     category: 'lumber',        name: 'Marine Plywood',     unit: 'sheets' },
  { id: 'phenolic_ply',   category: 'lumber',        name: 'Phenolic Plywood',   unit: 'sheets' },
  { id: 'ordinary_ply',   category: 'lumber',        name: 'Ordinary Plywood',   unit: 'sheets' },
  { id: 'mdf',            category: 'lumber',        name: 'MDF Board',          unit: 'sheets' },
  { id: 'particle',       category: 'lumber',        name: 'Particle Board',     unit: 'sheets' },
  { id: 'hardiflex',      category: 'lumber',        name: 'Hardiflex Board',    unit: 'sheets' },
  { id: 'wood_plank',     category: 'lumber',        name: 'Wood Planks',        unit: 'pcs' },
  { id: 'wood_mold',      category: 'lumber',        name: 'Wood Moldings',      unit: 'lengths' },

  // --- Roofing ---
  { id: 'longspan',       category: 'roofing',       name: 'Long-Span Roofing',  unit: 'lengths' },
  { id: 'corrugated',     category: 'roofing',       name: 'Corrugated Roofing', unit: 'sheets' },
  { id: 'rib_type',       category: 'roofing',       name: 'Rib-Type Roofing',   unit: 'sheets' },
  { id: 'roof_ridge',     category: 'roofing',       name: 'Roof Ridge',         unit: 'lengths' },
  { id: 'flashing',       category: 'roofing',       name: 'Flashing',           unit: 'lengths' },
  { id: 'roof_screws',    category: 'roofing',       name: 'Roof Screws',        unit: 'boxes' },
  { id: 'roof_sealant',   category: 'roofing',       name: 'Roof Sealant',       unit: 'tubes' },
  { id: 'insulation',     category: 'roofing',       name: 'Insulation',         unit: 'rolls' },
  { id: 'gutters',        category: 'roofing',       name: 'Gutters',            unit: 'lengths' },
  { id: 'downspouts',     category: 'roofing',       name: 'Downspouts',         unit: 'lengths' },

  // --- Hollow Blocks & Masonry ---
  { id: 'brick',          category: 'masonry',       name: 'Bricks',             unit: 'pcs' },
  { id: 'pavers',         category: 'masonry',       name: 'Pavers',             unit: 'pcs' },
  { id: 'curbstone',      category: 'masonry',       name: 'Curbstones',         unit: 'pcs' },
  { id: 'masonry_mort',   category: 'masonry',       name: 'Masonry Mortar',     unit: 'bags' },

  // --- Pipes & Plumbing ---
  { id: 'pvc_pipe',       category: 'plumbing',      name: 'PVC Pipe',           unit: 'lengths (6m)' },
  { id: 'upvc_pipe',      category: 'plumbing',      name: 'uPVC Pipe',          unit: 'lengths (6m)' },
  { id: 'hdpe_pipe',      category: 'plumbing',      name: 'HDPE Pipe',          unit: 'lengths' },
  { id: 'ppr_pipe',       category: 'plumbing',      name: 'PPR Pipe',           unit: 'lengths' },
  { id: 'gi_pipe',        category: 'plumbing',      name: 'GI Pipe',            unit: 'lengths (6m)' },
  { id: 'pvc_fitting',    category: 'plumbing',      name: 'PVC Fittings',       unit: 'pcs' },
  { id: 'faucet',         category: 'plumbing',      name: 'Faucets',            unit: 'pcs' },
  { id: 'valve',          category: 'plumbing',      name: 'Valves',             unit: 'pcs' },
  { id: 'hose_bib',       category: 'plumbing',      name: 'Hose Bibs',          unit: 'pcs' },
  { id: 'flex_hose',      category: 'plumbing',      name: 'Flexible Hose',      unit: 'pcs' },
  { id: 'water_tank',     category: 'plumbing',      name: 'Water Tank',         unit: 'pcs' },

  // --- Electrical ---
  { id: 'elec_wire',      category: 'electrical',    name: 'Electrical Wire',    unit: 'rolls' },
  { id: 'thhn_wire',      category: 'electrical',    name: 'THHN Wire',          unit: 'rolls' },
  { id: 'conduit',        category: 'electrical',    name: 'Conduit',            unit: 'lengths' },
  { id: 'junc_box',       category: 'electrical',    name: 'Junction Box',       unit: 'pcs' },
  { id: 'breaker',        category: 'electrical',    name: 'Circuit Breaker',    unit: 'pcs' },
  { id: 'panel_board',    category: 'electrical',    name: 'Panel Board',        unit: 'pcs' },
  { id: 'switch',         category: 'electrical',    name: 'Switches',           unit: 'pcs' },
  { id: 'outlet',         category: 'electrical',    name: 'Convenience Outlet', unit: 'pcs' },
  { id: 'led_bulb',       category: 'electrical',    name: 'LED Bulb',           unit: 'pcs' },
  { id: 'floodlight',     category: 'electrical',    name: 'Floodlight',         unit: 'pcs' },
  { id: 'elec_tape',      category: 'electrical',    name: 'Electrical Tape',    unit: 'rolls' },
  { id: 'cable_tie',      category: 'electrical',    name: 'Cable Ties',         unit: 'packs' },

  // --- Paint & Finishing ---
  { id: 'primer',         category: 'paint',         name: 'Primer',             unit: 'cans (4L)' },
  { id: 'flat_paint',     category: 'paint',         name: 'Flat Paint',         unit: 'cans (4L)' },
  { id: 'semi_gloss',     category: 'paint',         name: 'Semi-Gloss Paint',   unit: 'cans (4L)' },
  { id: 'gloss_paint',    category: 'paint',         name: 'Gloss Paint',        unit: 'cans (4L)' },
  { id: 'elastomeric',    category: 'paint',         name: 'Elastomeric Paint',  unit: 'cans (4L)' },
  { id: 'wp_paint',       category: 'paint',         name: 'Waterproofing Paint',unit: 'cans (4L)' },
  { id: 'wood_stain',     category: 'paint',         name: 'Wood Stain',         unit: 'cans (1L)' },
  { id: 'varnish',        category: 'paint',         name: 'Clear Varnish',      unit: 'cans (1L)' },
  { id: 'paint_thinner',  category: 'paint',         name: 'Paint Thinner',      unit: 'cans (1L)' },
  { id: 'roller',         category: 'paint',         name: 'Paint Roller',       unit: 'pcs' },
  { id: 'paint_brush',    category: 'paint',         name: 'Paint Brush',        unit: 'pcs' },
  { id: 'putty',          category: 'paint',         name: 'Putty',              unit: 'cans' },
  { id: 'skim_coat',      category: 'paint',         name: 'Skim Coat',          unit: 'bags' },

  // --- Tiles & Flooring ---
  { id: 'ceramic_tile',   category: 'tiles',         name: 'Ceramic Tiles',      unit: 'boxes' },
  { id: 'porcelain_tile', category: 'tiles',         name: 'Porcelain Tiles',    unit: 'boxes' },
  { id: 'granite_tile',   category: 'tiles',         name: 'Granite Tiles',      unit: 'boxes' },
  { id: 'vinyl_floor',    category: 'tiles',         name: 'Vinyl Flooring',     unit: 'sq.m.' },
  { id: 'spc_floor',      category: 'tiles',         name: 'SPC Flooring',       unit: 'sq.m.' },
  { id: 'tile_adhesive',  category: 'tiles',         name: 'Tile Adhesive',      unit: 'bags' },
  { id: 'tile_grout',     category: 'tiles',         name: 'Tile Grout',         unit: 'bags' },
  { id: 'tile_spacer',    category: 'tiles',         name: 'Tile Spacers',       unit: 'packs' },

  // --- Doors & Windows ---
  { id: 'steel_door',     category: 'doors',         name: 'Steel Door',         unit: 'pcs' },
  { id: 'wood_door',      category: 'doors',         name: 'Wooden Door',        unit: 'pcs' },
  { id: 'pvc_door',       category: 'doors',         name: 'PVC Door',           unit: 'pcs' },
  { id: 'alum_window',    category: 'doors',         name: 'Aluminum Window',    unit: 'pcs' },
  { id: 'sliding_win',    category: 'doors',         name: 'Sliding Window',     unit: 'pcs' },
  { id: 'casement_win',   category: 'doors',         name: 'Casement Window',    unit: 'pcs' },
  { id: 'door_knob',      category: 'doors',         name: 'Door Knob',          unit: 'pcs' },
  { id: 'hinge',          category: 'doors',         name: 'Hinges',             unit: 'pcs' },
  { id: 'lock_set',       category: 'doors',         name: 'Lock Set',           unit: 'pcs' },
  { id: 'door_closer',    category: 'doors',         name: 'Door Closer',        unit: 'pcs' },

  // --- Fasteners ---
  { id: 'common_nail',    category: 'fasteners',     name: 'Common Nails',       unit: 'kg' },
  { id: 'conc_nail',      category: 'fasteners',     name: 'Concrete Nails',     unit: 'kg' },
  { id: 'finish_nail',    category: 'fasteners',     name: 'Finishing Nails',    unit: 'kg' },
  { id: 'umbrella_nail',  category: 'fasteners',     name: 'Umbrella Nails',     unit: 'kg' },
  { id: 'roof_screw',     category: 'fasteners',     name: 'Roofing Screws',     unit: 'boxes' },
  { id: 'wood_screw',     category: 'fasteners',     name: 'Wood Screws',        unit: 'boxes' },
  { id: 'exp_bolt',       category: 'fasteners',     name: 'Expansion Bolts',    unit: 'pcs' },
  { id: 'anchor_bolt',    category: 'fasteners',     name: 'Anchor Bolts',       unit: 'pcs' },
  { id: 'nuts_bolts',     category: 'fasteners',     name: 'Nuts & Bolts',       unit: 'sets' },
  { id: 'washer',         category: 'fasteners',     name: 'Washers',            unit: 'pcs' },
  { id: 'rivet',          category: 'fasteners',     name: 'Rivets',             unit: 'boxes' },

  // --- Waterproofing & Sealants ---
  { id: 'sil_sealant',    category: 'waterproofing', name: 'Silicone Sealant',   unit: 'tubes' },
  { id: 'pu_sealant',     category: 'waterproofing', name: 'PU Sealant',         unit: 'tubes' },
  { id: 'constr_adh',     category: 'waterproofing', name: 'Construction Adhesive', unit: 'tubes' },
  { id: 'epoxy',          category: 'waterproofing', name: 'Epoxy',              unit: 'sets' },
  { id: 'wp_membrane',    category: 'waterproofing', name: 'Waterproofing Membrane', unit: 'rolls' },
  { id: 'cem_wp',         category: 'waterproofing', name: 'Cementitious Waterproofing', unit: 'bags' },
  { id: 'bitumen',        category: 'waterproofing', name: 'Bitumen Coating',    unit: 'cans' },

  // --- Tools ---
  { id: 'shovel',         category: 'tools',         name: 'Shovel',             unit: 'pcs' },
  { id: 'spade',          category: 'tools',         name: 'Spade',              unit: 'pcs' },
  { id: 'pick_mattock',   category: 'tools',         name: 'Pick Mattock',       unit: 'pcs' },
  { id: 'wheelbarrow',    category: 'tools',         name: 'Wheelbarrow',        unit: 'pcs' },
  { id: 'trowel',         category: 'tools',         name: 'Trowel',             unit: 'pcs' },
  { id: 'float',          category: 'tools',         name: 'Float',              unit: 'pcs' },
  { id: 'masons_line',    category: 'tools',         name: "Mason's Line",       unit: 'rolls' },
  { id: 'spirit_level',   category: 'tools',         name: 'Spirit Level',       unit: 'pcs' },
  { id: 'tape_measure',   category: 'tools',         name: 'Tape Measure',       unit: 'pcs' },
  { id: 'hammer',         category: 'tools',         name: 'Hammer',             unit: 'pcs' },
  { id: 'crowbar',        category: 'tools',         name: 'Crowbar',            unit: 'pcs' },
  { id: 'chisel',         category: 'tools',         name: 'Chisel',             unit: 'pcs' },
  { id: 'grinder',        category: 'tools',         name: 'Angle Grinder',      unit: 'pcs' },
  { id: 'circ_saw',       category: 'tools',         name: 'Circular Saw',       unit: 'pcs' },
  { id: 'drill',          category: 'tools',         name: 'Drill',              unit: 'pcs' },
  { id: 'impact_driver',  category: 'tools',         name: 'Impact Driver',      unit: 'pcs' },
  { id: 'mixer',          category: 'tools',         name: 'Concrete Mixer',     unit: 'pcs' },
  { id: 'vibrator',       category: 'tools',         name: 'Concrete Vibrator',  unit: 'pcs' },

  // --- Safety Equipment ---
  { id: 'hard_hat',       category: 'safety',        name: 'Hard Hat',           unit: 'pcs' },
  { id: 'safety_vest',    category: 'safety',        name: 'Safety Vest',        unit: 'pcs' },
  { id: 'safety_shoes',   category: 'safety',        name: 'Safety Shoes',       unit: 'pairs' },
  { id: 'safety_gloves',  category: 'safety',        name: 'Safety Gloves',      unit: 'pairs' },
  { id: 'goggles',        category: 'safety',        name: 'Goggles',            unit: 'pcs' },
  { id: 'ear_protect',    category: 'safety',        name: 'Ear Protection',     unit: 'pcs' },
  { id: 'dust_mask',      category: 'safety',        name: 'Dust Mask',          unit: 'boxes' },
  { id: 'respirator',     category: 'safety',        name: 'Respirator',         unit: 'pcs' },
  { id: 'harness',        category: 'safety',        name: 'Safety Harness',     unit: 'pcs' },

  // --- Hardware ---
  { id: 'padlock',        category: 'hardware',      name: 'Padlock',            unit: 'pcs' },
  { id: 'hw_hinge',       category: 'hardware',      name: 'Hinges',             unit: 'pcs' },
  { id: 'cab_handle',     category: 'hardware',      name: 'Cabinet Handles',    unit: 'pcs' },
  { id: 'drawer_slide',   category: 'hardware',      name: 'Drawer Slides',      unit: 'pairs' },
  { id: 'gate_latch',     category: 'hardware',      name: 'Gate Latch',         unit: 'pcs' },
  { id: 'door_stop',      category: 'hardware',      name: 'Door Stop',          unit: 'pcs' },
  { id: 'hooks',          category: 'hardware',      name: 'Hooks',              unit: 'pcs' },
  { id: 'chain',          category: 'hardware',      name: 'Chain',              unit: 'meters' },

  // --- Landscaping ---
  { id: 'topsoil',        category: 'landscaping',   name: 'Topsoil',            unit: 'cu.m.' },
  { id: 'garden_soil',    category: 'landscaping',   name: 'Garden Soil',        unit: 'bags (50kg)' },
  { id: 'deco_stones',    category: 'landscaping',   name: 'Decorative Stones',  unit: 'cu.m.' },
  { id: 'pebbles',        category: 'landscaping',   name: 'Pebbles',            unit: 'bags' },
  { id: 'river_rocks',    category: 'landscaping',   name: 'River Rocks',        unit: 'cu.m.' },
  { id: 'mulch',          category: 'landscaping',   name: 'Mulch',              unit: 'bags' },
  { id: 'compost',        category: 'landscaping',   name: 'Compost',            unit: 'bags' },
];

function TalkModal({ isOpen, callStatus, stopCall, callError, startCall }: any) {
  React.useEffect(() => {
    if (isOpen && typeof startCall === 'function') {
      startCall();
    }
  }, [isOpen, startCall]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-xl flex items-center justify-center px-4">
      <div className="liquid-glass-strong rounded-[2rem] p-8 w-full max-w-sm flex flex-col items-center gap-5">
        
        {/* 1. Title row */}
        <div className="w-full flex items-center justify-between">
          <span className="font-heading italic text-white text-3xl">Talk To Order</span>
          <button
            onClick={stopCall}
            className="w-9 h-9 rounded-full liquid-glass flex items-center justify-center text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 2. Animated status orb (mt-2) */}
        <div className="relative w-24 h-24 mt-2 flex items-center justify-center">
          {callStatus === 'connecting' && (
            <>
              <div className="absolute inset-0 rounded-full bg-white/5 border border-white/15 pulse-ring" />
              <div className="absolute inset-0 rounded-full bg-white/5 border border-white/15 pulse-ring" style={{ animationDelay: '0.4s' }} />
              <div className="absolute inset-0 m-auto w-16 h-16 liquid-glass-strong rounded-full flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" className="w-7 h-7 spin-arc">
                  <path d="M12 2a10 10 0 0 1 10 10" strokeLinecap="round"/>
                </svg>
              </div>
            </>
          )}

          {callStatus === 'active' && (
            <>
              <div className="absolute inset-0 rounded-full border border-white/10 pulse-ring" style={{ animationDuration: '2.5s' }} />
              <div className="absolute inset-0 m-auto w-16 h-16 liquid-glass-strong rounded-full flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-6 h-6">
                  <rect x="9" y="2" width="6" height="11" rx="3"/>
                  <path d="M5 10a7 7 0 0 0 14 0M12 19v3M8 22h8" strokeLinecap="round"/>
                </svg>
              </div>
            </>
          )}

          {callStatus === 'user-speaking' && (
            <>
              <div className="absolute inset-0 m-auto w-16 h-16 liquid-glass-strong rounded-full flex items-center justify-center" style={{ boxShadow: '0 0 20px rgba(255,255,255,0.2)' }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-6 h-6">
                  <rect x="9" y="2" width="6" height="11" rx="3"/>
                  <path d="M5 10a7 7 0 0 0 14 0M12 19v3M8 22h8" strokeLinecap="round"/>
                </svg>
              </div>
              <div className="absolute bottom-[-12px] left-0 right-0 flex gap-1 items-end justify-center">
                <div className="w-1.5 rounded-full bg-white/80 sound-bar" style={{ height: '12px' }} />
                <div className="w-1.5 rounded-full bg-white/80 sound-bar" style={{ height: '18px' }} />
                <div className="w-1.5 rounded-full bg-white/80 sound-bar" style={{ height: '24px' }} />
                <div className="w-1.5 rounded-full bg-white/80 sound-bar" style={{ height: '18px' }} />
                <div className="w-1.5 rounded-full bg-white/80 sound-bar" style={{ height: '12px' }} />
              </div>
            </>
          )}

          {callStatus === 'assistant-speaking' && (
            <>
              <div className="absolute inset-0 rounded-full border border-white/10 pulse-ring" />
              <div className="absolute inset-0 rounded-full border border-white/10 pulse-ring" style={{ animationDelay: '0.4s' }} />
              <div className="absolute inset-0 m-auto w-16 h-16 liquid-glass-strong rounded-full flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-6 h-6">
                  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="white" opacity="0.9"/>
                  <path d="M15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14" strokeLinecap="round"/>
                </svg>
              </div>
              <div className="absolute bottom-[-12px] left-0 right-0 flex gap-1 items-end justify-center">
                <div className="w-1.5 rounded-full bg-white/90 sound-bar" style={{ height: '16px' }} />
                <div className="w-1.5 rounded-full bg-white/90 sound-bar" style={{ height: '22px' }} />
                <div className="w-1.5 rounded-full bg-white/90 sound-bar" style={{ height: '30px' }} />
                <div className="w-1.5 rounded-full bg-white/90 sound-bar" style={{ height: '22px' }} />
                <div className="w-1.5 rounded-full bg-white/90 sound-bar" style={{ height: '16px' }} />
              </div>
            </>
          )}

          {callStatus === 'filled' && (
            <div className="absolute inset-0 m-auto w-16 h-16 bg-white/10 rounded-full flex items-center justify-center" style={{ boxShadow: '0 0 32px rgba(74,222,128,0.45)' }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="#4ade80" strokeWidth="2.5" className="w-8 h-8">
                <motion.path
                  d="M4 12l5 5L20 7"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.6, ease: 'easeOut' }}
                />
              </svg>
            </div>
          )}

          {callStatus === 'error' && (
            <div className="absolute inset-0 m-auto w-16 h-16 liquid-glass-strong rounded-full flex items-center justify-center" style={{ boxShadow: '0 0 24px rgba(248,113,113,0.4)' }}>
              <X className="w-8 h-8 text-white" />
            </div>
          )}
        </div>

        {/* 3. Status label */}
        <p className="text-sm font-body text-white/75 text-center mt-1">
          {callStatus === 'connecting' && "Connecting to assistant…"}
          {callStatus === 'active' && "Listening — speak now"}
          {callStatus === 'user-speaking' && "Got it, keep going…"}
          {callStatus === 'assistant-speaking' && "Assistant is speaking…"}
          {callStatus === 'filled' && "✓ Form filled! Scrolling to your order…"}
          {callStatus === 'error' && (callError || 'Connection failed. Please try again.')}
          {callStatus === 'idle' && "Ready"}
        </p>

        {/* 4. Hint text */}
        {callStatus !== 'filled' && callStatus !== 'error' && (
          <p className="text-xs text-white/40 font-body text-center max-w-[210px]">
            Tell us what materials you need and where to deliver — we'll fill the form for you.
          </p>
        )}

        {/* 5. End Call button */}
        {callStatus !== 'filled' && typeof stopCall === 'function' && (
          <button
            onClick={stopCall}
            className="mt-2 liquid-glass rounded-full px-8 py-2.5 text-sm font-body text-white cursor-pointer hover:bg-white/5 active:scale-95 transition-all"
          >
            {callStatus === 'connecting' ? "Cancel" : "End Call"}
          </button>
        )}

      </div>
    </div>
  );
}

(window as any).TalkModal = TalkModal;

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'order'>('order');
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);

  // Home Page Quote drawer state
  const [selectedMaterial, setSelectedMaterial] = useState("Washed Sand");
  const [tonnage, setTonnage] = useState(15);
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [deliveryDate, setDeliveryDate] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Cinematic Order Form App State
  const [quantities, setQuantities]         = useState<Record<string, number>>({});   // productId → number
  const [step, setStep]                     = useState<'order' | 'success'>('order'); // 'order' | 'success'
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting]     = useState(false);
  const [form, setForm]                     = useState({ name: '', mobile: '', address: '', notes: '' });

  const [activeCategory, setActiveCategory] = React.useState('aggregates');
  const [searchQuery,    setSearchQuery]    = React.useState('');

  const filteredProducts = React.useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (q) {
      return PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.unit.toLowerCase().includes(q)
      );
    }
    return PRODUCTS.filter(p => p.category === activeCategory);
  }, [activeCategory, searchQuery]);

  const selectedCount = React.useMemo(() =>
    Object.keys(quantities).filter(id => (quantities[id] || 0) > 0).length,
  [quantities]);

  const selectedTotal = React.useMemo(() =>
    PRODUCTS.filter(p => (quantities[p.id] || 0) > 0)
      .map(p => `${p.name} × ${quantities[p.id]}`)
      .join(', '),
  [quantities]);

  // Cloudflare Turnstile fallback states
  const [turnstileLoadFailed, setTurnstileLoadFailed] = useState(false);
  const [fallbackChecked, setFallbackChecked] = useState(false);

  const [isTalkOpen,  setIsTalkOpen]  = React.useState(false);
  const [callStatus,  setCallStatus]  = React.useState('idle');
  const [callError, setCallError] = React.useState('');
  const conversationRef = React.useRef<any>(null);
  const callIntervalRef = React.useRef<any>(null);

  const callStatusRef = React.useRef('idle');
  React.useEffect(() => {
    callStatusRef.current = callStatus;
  }, [callStatus]);

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsPrivacyOpen(false);
        setIsTermsOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const handleFillOrderForm = React.useCallback((params: any) => {
    setForm({
      name:    params?.customer_name    || '',
      mobile:  params?.mobile_number    || '',
      address: params?.delivery_address || '',
      notes:   params?.notes            || ''
    });

    const newQtys: Record<string, number> = {};
    if (Array.isArray(params?.items)) {
      params.items.forEach((item: any) => {
        if (item.product_id && Number(item.quantity) > 0) {
          newQtys[item.product_id] = Number(item.quantity);
        }
      });
    }
    setQuantities(newQtys);
    setCallStatus('filled');
    setActiveTab('order');

    setTimeout(() => {
      setIsTalkOpen(false);
      setCallStatus('idle');
      const el = document.getElementById('details-form') || document.getElementById('order-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 2500);

    return 'Form filled successfully.';
  }, []);

  const startCall = React.useCallback(async () => {
    setCallError('');

    if (conversationRef.current || ['connecting', 'active', 'assistant-speaking', 'user-speaking'].includes(callStatusRef.current)) {
      console.log('Call already active or starting, skipping startCall');
      return;
    }

    if (!ELEVENLABS_AGENT_ID || ELEVENLABS_AGENT_ID.startsWith('REPLACE_WITH')) {
      setCallError('Voice assistant is not configured yet (missing ElevenLabs Agent ID).');
      setCallStatus('error');
      return;
    }

    // Step 1: explicitly request microphone before starting
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
    } catch(micErr: any) {
      console.error('Microphone error:', micErr);
      if (micErr.name === 'NotAllowedError' || micErr.name === 'PermissionDeniedError') {
        setCallError('Microphone blocked. Tap the 🔒 lock icon in your browser address bar and allow microphone.');
      } else if (micErr.name === 'NotFoundError') {
        setCallError('No microphone found on this device.');
      } else {
        setCallError('Microphone error: ' + micErr.message);
      }
      setCallStatus('error');
      return;
    }

    // Step 2: start the ElevenLabs conversation
    setCallStatus('connecting');
    try {
      const conversation = await Conversation.startSession({
        agentId: ELEVENLABS_AGENT_ID,
        clientTools: {
          fill_order_form: (params: any) => handleFillOrderForm(params),
        },
        onConnect: () => {
          console.log('Call started');
          setCallStatus('active');
        },
        onDisconnect: () => {
          console.log('Call ended');
          conversationRef.current = null;
          setCallStatus((prev: any) => prev !== 'filled' ? 'idle' : prev);
        },
        onModeChange: ({ mode }: any) => {
          if (mode === 'speaking') {
            console.log('Assistant speaking');
            setCallStatus('assistant-speaking');
          } else {
            console.log('Assistant finished');
            setCallStatus((prev: any) => prev === 'filled' ? prev : 'active');
          }
        },
        onMessage: (message: any) => {
          console.log(message);
        },
        onError: (message: any) => {
          console.error("========== ELEVENLABS ERROR ==========");
          console.error(message);
          setCallError(typeof message === 'string' ? message : (message?.message || 'Connection failed. Please try again.'));
          setCallStatus('error');
        },
      });

      conversationRef.current = conversation;
    } catch(callErr: any) {
      console.error('Call start error:', callErr);
      setCallError(callErr?.message || 'Could not connect. Check your ElevenLabs agent ID is correct and the agent is public.');
      setCallStatus('error');
    }
  }, [handleFillOrderForm]);

  const stopCall = React.useCallback(() => {
    console.log('Stopping call');
    const conversation = conversationRef.current;
    if (conversation) {
      try { conversation.endSession(); } catch(e) { console.error('Stop error:', e); }
    }
    conversationRef.current = null;
    setCallStatus('idle');
    setIsTalkOpen(false);
  }, []);

  // Cloudflare Turnstile initialization
  useEffect(() => {
    let timer: any;
    let retries = 0;
    const maxRetries = 10;

    const initTurnstile = () => {
      const container = document.getElementById('turnstile-container');
      if (!container) return;
      
      if ((window as any).turnstile) {
        try {
          (window as any).turnstile.render('#turnstile-container', {
            sitekey: TURNSTILE_SITEKEY,
            theme: 'dark',
            callback: (token: string) => {
              setTurnstileToken(token);
            },
            'expired-callback': () => {
              setTurnstileToken(null);
            },
          });
        } catch (e) {
          console.warn("Turnstile rendering exception:", e);
          setTurnstileLoadFailed(true);
        }
      } else {
        retries++;
        if (retries < maxRetries) {
          timer = setTimeout(initTurnstile, 500);
        } else {
          console.warn("Cloudflare Turnstile script failed to load or was blocked.");
          setTurnstileLoadFailed(true);
        }
      }
    };

    if (activeTab === 'order' && step === 'order') {
      initTurnstile();
    }

    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [activeTab, step]);

  // Stepper handlers
  const updateQuantity = (id: string, amount: number) => {
    setQuantities(prev => {
      const current = prev[id] || 0;
      const next = Math.max(0, current + amount);
      return { ...prev, [id]: next };
    });
  };

  const handleQtyInputChange = (id: string, value: string) => {
    const parsed = parseInt(value, 10);
    const next = isNaN(parsed) ? 0 : Math.max(0, parsed);
    setQuantities(prev => ({ ...prev, [id]: next }));
  };

  // Scroll helper
  const scrollToSection = (id: string) => {
    if (activeTab !== 'home') {
      setActiveTab('home');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToOrderId = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  // Home quote calculations
  const unitPrice = MATERIAL_PRICES[selectedMaterial] || 45;
  const materialsSubtotal = unitPrice * tonnage;
  const flatDeliveryFee = 150;
  const estimatedTax = Math.round(materialsSubtotal * 0.0825);
  const totalCost = materialsSubtotal + flatDeliveryFee + estimatedTax;

  const handleSubmitQuote = (e: FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone || !email || !deliveryAddress) {
      alert("Please fill in all required fields.");
      return;
    }
    setIsSubmitted(true);
  };

  const handleResetForm = () => {
    setIsSubmitted(false);
    setFullName("");
    setPhone("");
    setEmail("");
    setDeliveryAddress("");
    setDeliveryDate("");
    setIsQuoteOpen(false);
  };

  // Order Submission to Discord Webhook
  const handleSubmitOrder = async (e: FormEvent) => {
    e.preventDefault();
    if (!turnstileToken) return;

    const selected = PRODUCTS.filter(p => (quantities[p.id] || 0) > 0);
    if (!selected.length) {
      alert('Please select at least one product.');
      return;
    }
    if (!form.name || !form.mobile || !form.address) {
      alert('Please fill in all required fields.');
      return;
    }

    setIsSubmitting(true);

    const orderLines = selected
      .map(p => `• **${p.name}** — ${quantities[p.id]} ${p.unit}`)
      .join('\n');

    const payload = {
      username: 'Thatamarketing Orders 📦',
      embeds: [{
        title: '🛒 New Order Received',
        color: 0xF59E0B,
        fields: [
          { name: '👤 Customer Name', value: form.name,    inline: true  },
          { name: '📱 Mobile Number', value: form.mobile,  inline: true  },
          { name: '📍 Delivery Address', value: form.address, inline: false },
          { name: '📦 Order Details',  value: orderLines,  inline: false },
          { name: '📝 Notes',          value: form.notes || '—', inline: false },
        ],
        footer: { text: 'Thatamarketing Order System' },
        timestamp: new Date().toISOString(),
      }],
    };

    try {
      await fetch(DISCORD_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      setStep('success');
    } catch (err) {
      alert('Something went wrong. Please try again or call us directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetOrder = () => {
    setQuantities({});
    setForm({ name: '', mobile: '', address: '', notes: '' });
    setTurnstileToken(null);
    setFallbackChecked(false);
    setStep('order');
    if ((window as any).turnstile) {
      try {
        (window as any).turnstile.reset();
      } catch (e) {}
    }
  };

  // Count active order selection items
  const selectedProducts = PRODUCTS.filter(p => (quantities[p.id] || 0) > 0);
  const totalSelectedCount = selectedProducts.length;

  return (
    <div className="relative min-h-screen text-white font-body selection:bg-white/20 selection:text-white bg-black overflow-x-hidden">
      
      {/* PERSISTENT CINEMATIC VIDEO BACKGROUND */}
      <div className="fixed inset-0 w-full h-full z-0 overflow-hidden pointer-events-none">
        <FadingVideo
          src={activeTab === 'order' ? BG_VIDEO_URL : BG_VIDEO_URL}
          className="absolute inset-0 w-full h-full object-cover opacity-0 filter brightness-[0.7] scale-100"
        />
        {/* Subtle radial vignette to pull focus to the center content */}
        <div className="absolute inset-0 bg-radial from-transparent via-black/30 to-black/80 pointer-events-none" />
      </div>

      {/* NAVBAR */}
      <header className="fixed top-4 left-0 right-0 z-50 px-4 md:px-8 lg:px-16 max-w-7xl mx-auto">
        <div className="flex items-center justify-between w-full">
          {/* Logo */}
          <button
            onClick={() => {
              setActiveTab('home');
              setTimeout(() => {
                const el = document.getElementById("hero");
                if (el) el.scrollIntoView({ behavior: "smooth" });
              }, 100);
            }}
            className="w-12 h-12 rounded-full liquid-glass flex items-center justify-center cursor-pointer transition-transform hover:scale-105 active:scale-95 overflow-hidden"
            id="nav-logo"
          >
            <img 
              src="https://cdn.phototourl.com/free/2026-06-26-056ccdd2-3782-494c-855f-9d5f73c39022.png" 
              alt="ThataMarketing Logo" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </button>

          {/* Center Navigation */}
          <nav className="hidden md:flex items-center gap-1 p-1.5 rounded-full liquid-glass max-w-lg">
            <button
              onClick={() => {
                setActiveTab('home');
                setTimeout(() => {
                  const el = document.getElementById("hero");
                  if (el) el.scrollIntoView({ behavior: "smooth" });
                }, 100);
              }}
              className={`px-4 py-2 text-sm font-medium rounded-full transition-all cursor-pointer ${
                activeTab === 'home' ? 'text-white bg-white/10' : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("materials")}
              className="px-4 py-2 text-sm font-medium text-white/60 hover:text-white rounded-full transition-colors cursor-pointer hover:bg-white/5"
            >
              Materials
            </button>
            <button
              onClick={() => setActiveTab('order')}
              className={`px-4 py-2 text-sm font-medium rounded-full transition-all cursor-pointer ${
                activeTab === 'order' ? 'text-black bg-white font-semibold' : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Order
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="px-4 py-2 text-sm font-medium text-white/60 hover:text-white rounded-full transition-colors cursor-pointer hover:bg-white/5"
            >
              About
            </button>
            <button
              onClick={() => {
                if (activeTab === 'order') {
                  const el = document.getElementById("order-section");
                  if (el) el.scrollIntoView({ behavior: "smooth" });
                } else {
                  scrollToSection("quote-band");
                }
              }}
              className="px-4 py-2 text-sm font-medium text-white/60 hover:text-white rounded-full transition-colors cursor-pointer hover:bg-white/5"
            >
              Contact
            </button>
            
            {activeTab === 'home' ? (
              <button
                onClick={() => {
                  setActiveTab('order');
                  setTimeout(() => {
                    const el = document.getElementById("order-section");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }, 100);
                }}
                className="ml-2 bg-white text-black hover:bg-white/90 font-medium px-4 py-2 text-sm rounded-full flex items-center gap-1.5 transition-all whitespace-nowrap shadow-lg shadow-white/5 active:scale-95 cursor-pointer"
              >
                Place an Order <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            ) : (
              <button
                onClick={() => {
                  const el = document.getElementById("order-section");
                  if (el) el.scrollIntoView({ behavior: "smooth" });
                }}
                className="ml-2 bg-white/10 text-white hover:bg-white/20 font-medium px-4 py-2 text-sm rounded-full flex items-center gap-1.5 transition-all whitespace-nowrap active:scale-95 cursor-pointer"
              >
                Go to Form <ArrowUpRight className="w-4 h-4" />
              </button>
            )}
          </nav>

          {/* Right Mobile Menu Trigger / Glass Spacer */}
          <div className="flex md:hidden gap-1.5">
            {activeTab === 'home' ? (
              <>
                <button
                  onClick={() => {
                    setActiveTab('order');
                    setTimeout(() => {
                      const el = document.getElementById("order-section");
                      if (el) el.scrollIntoView({ behavior: "smooth" });
                    }, 100);
                  }}
                  className="bg-white/10 text-white font-semibold px-3 py-2 text-xs rounded-full cursor-pointer"
                >
                  Order
                </button>
                <button
                  onClick={() => {
                    setActiveTab('order');
                    setTimeout(() => {
                      const el = document.getElementById("order-section");
                      if (el) el.scrollIntoView({ behavior: "smooth" });
                    }, 100);
                  }}
                  className="bg-white text-black font-semibold px-3 py-2 text-xs rounded-full flex items-center gap-1 transition-transform active:scale-95 cursor-pointer"
                >
                  Order <ArrowUpRight className="w-3.5 h-3.5 stroke-[2.5]" />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setActiveTab('home')}
                  className="bg-white/10 text-white font-semibold px-3 py-2 text-xs rounded-full cursor-pointer"
                >
                  Home
                </button>
                <button
                  onClick={() => {
                    const el = document.getElementById("order-section");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="bg-white text-black font-semibold px-3 py-2 text-xs rounded-full cursor-pointer"
                >
                  Form ↓
                </button>
              </>
            )}
          </div>

          <div className="hidden md:block w-12 h-12 opacity-0 pointer-events-none" />
        </div>
      </header>

      {/* RENDER ACTIVE TAB */}
      <AnimatePresence mode="wait">
        {activeTab === 'order' ? (
          /* ==========================================
             CINEMATIC ORDER FORM PAGE
             ========================================== */
          <motion.div
            key="order-page"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* HERO SECTION */}
            <section
              id="order-hero"
              className="relative z-10 min-h-screen flex flex-col justify-between items-center pt-32 pb-16 px-4 max-w-7xl mx-auto"
            >
              <div className="flex-1 flex flex-col items-center justify-center text-center max-w-4xl mt-8">
                {/* Badge (delay 0.3s) */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
                  className="mb-8 p-1 pr-4 rounded-full liquid-glass flex items-center gap-3 max-w-full"
                >
                  <span className="bg-white text-black px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full flex items-center justify-center">
                    New
                  </span>
                  <span className="text-xs md:text-sm text-white/90 font-light truncate">
                    Order Online & We'll Deliver To Your Site
                  </span>
                </motion.div>

                {/* Headline: BlurText word-by-word */}
                <div className="mb-6">
                  <BlurText
                    text="Order Materials. We Deliver."
                    className="text-6xl md:text-7xl lg:text-[5.5rem] font-heading italic text-white leading-[0.9] tracking-[-3px] justify-center"
                  />
                </div>

                {/* Subheading (delay 0.8s) */}
                <motion.p
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }}
                  className="text-sm md:text-base text-white/90 font-body font-light max-w-xl mt-4 leading-relaxed"
                >
                  Select the materials you need, give us your details, and we'll confirm your delivery window — fast.
                </motion.p>

                {/* CTA (delay 1.0s) */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 1.0, ease: "easeOut" }}
                  className="mt-10"
                >
                  <button
                    onClick={() => scrollToOrderId("order-section")}
                    className="liquid-glass-strong rounded-full px-8 py-4 text-sm font-medium text-white flex items-center justify-center gap-2 hover:bg-white/10 active:scale-95 transition-all duration-300 cursor-pointer"
                  >
                    Start Your Order ↓
                  </button>
                </motion.div>
              </div>

              {/* Bottom credentials strip */}
              <div className="w-full relative z-10 bg-black/40 border-t border-white/5 py-4 px-4 md:px-16 flex flex-wrap items-center justify-center md:justify-between text-[11px] font-medium tracking-widest text-white/40 uppercase gap-2 mt-12">
                <span>DOT-Certified Fleet</span>
                <span className="hidden md:inline text-white/10">•</span>
                <span>Licensed & Insured</span>
                <span className="hidden md:inline text-white/10">•</span>
                <span>20+ Years Experience</span>
                <span className="hidden md:inline text-white/10">•</span>
                <span>Locally Owned Operation</span>
              </div>
            </section>

            {/* ORDER FORM SECTION */}
            <section
              id="order-section"
              className="relative z-10 min-h-screen px-6 md:px-16 py-20 bg-black/95 border-t border-white/5"
            >
              {/* Aggregates background video inside order section */}
              <div className="absolute inset-0 w-full h-full z-0 overflow-hidden pointer-events-none opacity-20">
                <FadingVideo
                  src={AGGREGATE_VIDEO_URL}
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>

              <div className="relative z-10 max-w-7xl mx-auto">
                <AnimatePresence mode="wait">
                  {step === 'order' ? (
                    <motion.div
                      key="order-step-container"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.5 }}
                      className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8"
                    >
                      {/* LEFT COLUMN: PRODUCT SELECTION */}
                      <div className="space-y-6">
                        {/* Search bar */}
                        <div className="relative w-full mb-6">
                          <input
                            type="text"
                            className="w-full bg-white/5 border border-white/10 rounded-full pl-11 pr-10 py-3 text-sm text-white placeholder-white/30 font-body outline-none focus:border-white/30 transition-colors"
                            placeholder="Search all products… e.g. sand, cement, PVC"
                            value={searchQuery}
                            onChange={(e) => { setSearchQuery(e.target.value); }}
                          />
                          <div className="absolute left-4 top-1/2 -translate-y-1/2">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                 stroke="rgba(255,255,255,0.35)" strokeWidth="2" strokeLinecap="round">
                              <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
                            </svg>
                          </div>
                          {searchQuery && (
                            <button
                              onClick={() => setSearchQuery('')}
                              className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center text-white/40 hover:text-white/75 transition-colors cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          )}
                        </div>

                        {/* Category tabs */}
                        {!searchQuery && (
                          <div className="-mx-2 px-2 overflow-x-auto pb-3 mb-6 scrollbar-hide">
                            <div className="flex gap-2 w-max">
                              {CATEGORIES.map((cat) => {
                                const isActive = activeCategory === cat.id;
                                return (
                                  <button
                                    key={cat.id}
                                    onClick={() => {
                                      setActiveCategory(cat.id);
                                      setSearchQuery('');
                                    }}
                                    className={`flex items-center gap-2 px-4 py-2 rounded-full cursor-pointer whitespace-nowrap transition-all font-body text-sm ${
                                      isActive
                                        ? "bg-white/15 text-white border border-white/20"
                                        : "bg-white/0 text-white/45 border border-transparent hover:text-white/70 hover:bg-white/5"
                                    }`}
                                  >
                                    <span>{cat.icon}</span>
                                    <span>{cat.label}</span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* Section header */}
                        {searchQuery ? (
                          <div className="flex items-center gap-3 mb-5">
                            <h3 className="font-heading italic text-white text-2xl">
                              Showing {filteredProducts.length} results for "{searchQuery}"
                            </h3>
                          </div>
                        ) : (
                          (() => {
                            const cat = CATEGORIES.find(c => c.id === activeCategory);
                            const count = filteredProducts.length;
                            return (
                              <div className="flex items-center gap-3 mb-5">
                                <span className="text-2xl">{cat?.icon}</span>
                                <h3 className="font-heading italic text-white text-3xl tracking-[-1px]">
                                  {cat?.label}
                                </h3>
                                <span className="liquid-glass rounded-full px-2.5 py-1 text-xs font-body text-white/50">
                                  {count} product{count !== 1 ? 's' : ''}
                                </span>
                              </div>
                            );
                          })()
                        )}

                        {/* Product grid with category/search key to reset grid animation on tab switch */}
                        <motion.div
                          key={searchQuery ? 'search' : activeCategory}
                          className="grid grid-cols-1 sm:grid-cols-2 gap-3"
                        >
                          {filteredProducts.map((product, index) => {
                            const qty = quantities[product.id] || 0;
                            return (
                              <motion.div
                                key={product.id}
                                initial={{ opacity: 0, y: 16 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.025, duration: 0.3 }}
                                className={`liquid-glass rounded-2xl p-4 flex flex-col justify-between gap-3 transition-all duration-200 ${
                                  qty > 0 ? "bg-white/10" : ""
                                }`}
                                style={{
                                  boxShadow: qty > 0 ? "inset 0 0 0 1.5px rgba(255,255,255,0.3)" : undefined
                                }}
                              >
                                {/* Top section */}
                                <div className="flex items-start justify-between gap-2">
                                  <div className="flex flex-col text-left">
                                    <span className="text-sm font-body font-medium text-white leading-snug">
                                      {product.name}
                                    </span>
                                    <span className="liquid-glass rounded-full px-2 py-0.5 text-[10px] font-body text-white/50 mt-1 w-fit">
                                      {product.unit}
                                    </span>
                                  </div>
                                  {qty > 0 && (
                                    <div className="w-6 h-6 rounded-full bg-white text-black text-xs font-body font-bold flex items-center justify-center flex-shrink-0">
                                      {qty}
                                    </div>
                                  )}
                                </div>

                                {/* Bottom section */}
                                <div className="flex items-center justify-between mt-1">
                                  <button
                                    type="button"
                                    onClick={() => updateQuantity(product.id, -1)}
                                    disabled={qty === 0}
                                    className={`w-8 h-8 liquid-glass-strong rounded-full flex items-center justify-center cursor-pointer text-white text-lg font-light transition-all ${
                                      qty === 0 ? "opacity-30 cursor-not-allowed" : "hover:bg-white/10"
                                    }`}
                                  >
                                    –
                                  </button>
                                  <span className="w-10 text-center text-sm font-body font-medium text-white">
                                    {qty > 0 ? qty : <span className="text-white/30">—</span>}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => updateQuantity(product.id, 1)}
                                    className="w-8 h-8 liquid-glass-strong rounded-full flex items-center justify-center cursor-pointer text-white text-lg font-light hover:bg-white/10 transition-all"
                                  >
                                    +
                                  </button>
                                </div>
                              </motion.div>
                            );
                          })}
                        </motion.div>
                      </div>

                      {/* RIGHT COLUMN: STICKY SUMMARY & ORDER DETAILS FORM */}
                      <div className="space-y-6">
                        <div className="lg:sticky lg:top-24 space-y-6">
                          {/* Order Summary Card */}
                          <div className="liquid-glass-strong rounded-[1.5rem] p-6 border border-white/5">
                            <h3 className="font-heading italic text-white text-2xl mb-4">
                              Your Order
                            </h3>

                            {totalSelectedCount === 0 ? (
                              <p className="text-white/40 text-sm font-body">
                                No items selected yet.
                              </p>
                            ) : (
                              <div className="space-y-3">
                                <div className="max-h-[220px] overflow-y-auto space-y-2.5 pr-1">
                                  {selectedProducts.map((p) => (
                                    <div key={p.id} className="flex items-center justify-between gap-3 text-sm font-body py-1 border-b border-white/5 last:border-0">
                                      <div className="flex flex-col text-left min-w-0">
                                        <span className="text-white/80 font-medium truncate max-w-[160px]">{p.name}</span>
                                        <span className="text-[10px] text-white/40 block font-body">Per {p.unit}</span>
                                      </div>
                                      <div className="flex items-center gap-2 shrink-0">
                                        <button
                                          type="button"
                                          onClick={() => updateQuantity(p.id, -1)}
                                          className="w-5 h-5 rounded-full liquid-glass flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 text-xs cursor-pointer"
                                        >
                                          –
                                        </button>
                                        <span className="text-white font-semibold text-xs min-w-[32px] text-right">
                                          {quantities[p.id]} {p.unit}
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() => updateQuantity(p.id, 1)}
                                          className="w-5 h-5 rounded-full liquid-glass flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 text-xs cursor-pointer"
                                        >
                                          +
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>

                                <div className="border-t border-white/10 my-3 pt-3 flex justify-between items-center">
                                  <span className="text-xs text-white/50 uppercase tracking-wider font-mono">Selected Items</span>
                                  <span className="text-sm font-semibold font-body text-white">
                                    {totalSelectedCount} product(s) selected
                                  </span>
                                </div>

                                {quantities['other'] > 0 && (
                                  <div className="border-t border-white/10 pt-3 mt-2 text-left space-y-1">
                                    <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider block">⚠️ Note for Unlisted Materials:</span>
                                    <p className="text-xs text-white/70 leading-relaxed">
                                      These items will be handled as <strong className="text-white font-medium">"Other Construction Supplies"</strong>. Requested materials: <span className="text-amber-300 font-medium">{form.notes || "(Please specify in Order Notes below)"}</span>
                                    </p>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Customer Details Form */}
                          <form id="details-form" onSubmit={handleSubmitOrder} className="liquid-glass-strong rounded-[1.5rem] p-6 border border-white/5 space-y-4">
                            <h3 className="font-heading italic text-white text-2xl">
                              Your Details
                            </h3>

                            {/* Full Name */}
                            <div className="flex flex-col text-left">
                              <label className="text-[11px] text-white/50 font-body uppercase tracking-wider mb-1">
                                Full Name *
                              </label>
                              <input
                                type="text"
                                required
                                placeholder="Juan dela Cruz"
                                value={form.name}
                                onChange={(e) => setForm(prev => ({ ...prev, name: e.target.value }))}
                                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 font-body outline-none focus:border-white/30 transition-colors"
                              />
                            </div>

                            {/* Mobile Number */}
                            <div className="flex flex-col text-left">
                              <label className="text-[11px] text-white/50 font-body uppercase tracking-wider mb-1">
                                Mobile Number *
                              </label>
                              <input
                                type="tel"
                                required
                                placeholder="+63 9XX XXX XXXX"
                                value={form.mobile}
                                onChange={(e) => setForm(prev => ({ ...prev, mobile: e.target.value }))}
                                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 font-body outline-none focus:border-white/30 transition-colors"
                              />
                            </div>

                            {/* Delivery Address */}
                            <div className="flex flex-col text-left">
                              <label className="text-[11px] text-white/50 font-body uppercase tracking-wider mb-1">
                                Delivery Address *
                              </label>
                              <input
                                type="text"
                                required
                                placeholder="Street, Barangay, City"
                                value={form.address}
                                onChange={(e) => setForm(prev => ({ ...prev, address: e.target.value }))}
                                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 font-body outline-none focus:border-white/30 transition-colors"
                              />
                            </div>

                            {/* Notes */}
                            <div className="flex flex-col text-left">
                              <label className="text-[11px] text-white/50 font-body uppercase tracking-wider mb-1">
                                Notes
                              </label>
                              <textarea
                                rows={3}
                                placeholder="e.g. call before delivery, gate code, etc."
                                value={form.notes}
                                onChange={(e) => setForm(prev => ({ ...prev, notes: e.target.value }))}
                                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 font-body outline-none focus:border-white/30 transition-colors resize-none"
                              />
                            </div>

                            {/* Cloudflare Turnstile Verification Widget */}
                            <div className="mt-4 border-t border-white/5 pt-4">
                              <p className="text-[11px] text-white/40 font-body mb-2 text-center">
                                Please verify you're human before placing your order.
                              </p>
                              {turnstileLoadFailed ? (
                                <div className="flex items-center justify-center gap-2.5 p-3.5 bg-white/[0.02] rounded-2xl border border-white/10 max-w-sm mx-auto">
                                  <input
                                    type="checkbox"
                                    id="fallback-verify"
                                    checked={fallbackChecked}
                                    onChange={(e) => {
                                      setFallbackChecked(e.target.checked);
                                      if (e.target.checked) {
                                        setTurnstileToken("bypass_token");
                                      } else {
                                        setTurnstileToken(null);
                                      }
                                    }}
                                    className="w-4 h-4 rounded border-white/20 text-white focus:ring-0 accent-white shrink-0 cursor-pointer"
                                  />
                                  <label htmlFor="fallback-verify" className="text-xs text-white/70 hover:text-white cursor-pointer select-none text-left">
                                    I confirm that I am human and ready to request these supplies.
                                  </label>
                                </div>
                              ) : (
                                <div id="turnstile-container" className="mt-2 flex justify-center min-h-[65px]" />
                              )}
                            </div>

                            {/* Place Order Button */}
                            <button
                              type="submit"
                              disabled={!turnstileToken || isSubmitting || totalSelectedCount === 0}
                              className={`mt-4 w-full liquid-glass-strong rounded-full py-3 text-sm font-medium text-white flex items-center justify-center gap-2 cursor-pointer transition-opacity ${
                                (!turnstileToken || totalSelectedCount === 0) ? "opacity-50 cursor-not-allowed" : "hover:bg-white/10"
                              } ${isSubmitting ? "opacity-75 pointer-events-none" : ""}`}
                            >
                              {isSubmitting ? (
                                <>
                                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                  </svg>
                                  Placing Order...
                                </>
                              ) : (
                                <>
                                  Place Order <ArrowUpRight className="w-4 h-4" />
                                </>
                              )}
                            </button>
                          </form>
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    /* ==========================================
                       SUCCESS SCREEN (Section 3)
                       ========================================== */
                    <motion.div
                      key="order-success-screen"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="min-h-[70vh] flex flex-col items-center justify-center gap-6 py-20 text-center relative z-10"
                    >
                      <div className="w-20 h-20 rounded-full bg-white text-black flex items-center justify-center shadow-2xl">
                        <svg className="w-10 h-10 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3">
                          <motion.path
                            initial={{ pathLength: 0 }}
                            animate={{ pathLength: 1 }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      </div>

                      <h2 className="font-heading italic text-white text-5xl md:text-6xl tracking-[-2px] leading-tight">
                        Order Received!
                      </h2>

                      <p className="font-body text-white/80 text-base max-w-md leading-relaxed">
                        We've got your request. Our team will contact you on <strong className="text-white font-semibold">{form.mobile}</strong> to confirm your delivery window.
                      </p>

                      {quantities['other'] > 0 && (
                        <div className="bg-amber-500/5 border border-amber-500/10 rounded-2xl p-5 text-left space-y-2 max-w-md w-full">
                          <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider block font-semibold">⚠️ Custom Order Note</span>
                          <p className="text-xs text-white/70 leading-relaxed font-body">
                            The following requested materials will be handled as <strong className="text-white">"Other Construction Supplies"</strong>:
                          </p>
                          <p className="text-xs text-amber-300 font-mono bg-black/30 p-3 rounded-xl border border-white/5 break-words">
                            {form.notes || "(No specific materials listed in notes)"}
                          </p>
                        </div>
                      )}

                      <div className="bg-white/5 p-5 rounded-2xl border border-white/10 w-full max-w-md text-left space-y-2.5 text-xs font-mono text-white/70">
                        <div className="flex justify-between border-b border-white/5 pb-2">
                          <span>Recipient Name:</span>
                          <span className="text-white">{form.name}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-2">
                          <span>Delivery Address:</span>
                          <span className="text-white truncate max-w-[240px]">{form.address}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-2">
                          <span>Verified Status:</span>
                          <span className="text-emerald-400 font-bold uppercase">Human Verified</span>
                        </div>
                        <div className="flex justify-between pt-1">
                          <span>Selected Items:</span>
                          <span className="text-white font-semibold">{selectedProducts.length} unique material(s)</span>
                        </div>
                      </div>

                      <button
                        onClick={handleResetOrder}
                        className="liquid-glass-strong px-8 py-3.5 text-sm font-semibold rounded-full hover:bg-white/10 transition-colors cursor-pointer"
                      >
                        Place Another Order
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </section>
          </motion.div>
        ) : (
          /* ==========================================
             ORIGINAL POLISHED MARKETING LANDING PAGE
             ========================================== */
          <motion.div
            key="home-page"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* HERO SECTION */}
            <section
              id="hero"
              className="relative z-10 min-h-screen flex flex-col justify-between items-center pt-32 pb-16 px-4 max-w-7xl mx-auto"
            >
              <div className="flex-1 flex flex-col items-center justify-center text-center max-w-4xl mt-8">
                {/* Badge: delay 0.4s */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
                  className="mb-8 p-1 pr-4 rounded-full liquid-glass flex items-center gap-3 max-w-full"
                >
                  <span className="bg-white text-black px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full flex items-center justify-center">
                    New
                  </span>
                  <span className="text-xs md:text-sm text-white/90 font-light truncate">
                    Same-Day Bulk Delivery Now Available
                  </span>
                </motion.div>

                {/* Headline: BlurText word-by-word */}
                <div className="mb-6">
                  <BlurText
                    text="From The Quarry To Your Job Site"
                    className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-heading italic text-white leading-[0.95] max-w-3xl justify-center tracking-[-2px] md:tracking-[-3px]"
                  />
                </div>

                {/* Subheading: delay 0.8s */}
                <motion.p
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.8, ease: "easeOut" }}
                  className="text-sm md:text-base lg:text-lg text-white/80 max-w-2xl font-light leading-relaxed mb-10 px-4"
                >
                  We supply premium sand, gravel, and crushed stone to contractors, builders, and homeowners — screened for quality, weighed for accuracy, and delivered when you need it.
                </motion.p>

                {/* CTAs: delay 1.1s */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 1.1, ease: "easeOut" }}
                  className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 mb-16"
                >
                  <button
                    onClick={() => {
                      setActiveTab('order');
                      setTimeout(() => {
                        const el = document.getElementById('order-section');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }, 100);
                    }}
                    className="w-full sm:w-auto liquid-glass-strong rounded-full px-7 py-3.5 text-sm font-medium text-white flex items-center justify-center gap-2 hover:bg-white/10 active:scale-95 transition-all duration-300 cursor-pointer"
                  >
                    Place an Order <ArrowUpRight className="w-4 h-4 stroke-[2]" />
                  </button>
                  <button
                    onClick={() => setIsVideoModalOpen(true)}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 text-white/80 hover:text-white text-sm font-medium transition-colors duration-300 py-3.5 px-4 cursor-pointer"
                  >
                    <span className="w-8 h-8 rounded-full liquid-glass flex items-center justify-center hover:bg-white/5">
                      <Play className="w-3.5 h-3.5 fill-white stroke-none" />
                    </span>
                    See Us In Action
                  </button>
                </motion.div>

                {/* Stats Row: delay 1.3s */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 1.3, ease: "easeOut" }}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-lg px-4"
                >
                  {/* Stat 1 */}
                  <div className="liquid-glass p-5 rounded-[1.25rem] text-left flex flex-col justify-between min-h-[140px] hover:bg-white/[0.03] transition-all">
                    <div className="flex items-center justify-between">
                      <Clock className="w-7 h-7 text-white/90 stroke-[1.5]" />
                      <span className="text-[10px] uppercase font-mono tracking-wider text-white/40">SLA Verified</span>
                    </div>
                    <div className="mt-4">
                      <h4 className="text-4xl tracking-[-1px] leading-none font-heading italic text-white">
                        24–48 Hrs
                      </h4>
                      <p className="text-xs text-white/60 font-light mt-2 font-body">
                        Average Delivery Turnaround
                      </p>
                    </div>
                  </div>

                  {/* Stat 2 */}
                  <div className="liquid-glass p-5 rounded-[1.25rem] text-left flex flex-col justify-between min-h-[140px] hover:bg-white/[0.03] transition-all">
                    <div className="flex items-center justify-between">
                      <MapPin className="w-7 h-7 text-white/90 stroke-[1.5]" />
                      <span className="text-[10px] uppercase font-mono tracking-wider text-white/40">Scale Volume</span>
                    </div>
                    <div className="mt-4">
                      <h4 className="text-4xl tracking-[-1px] leading-none font-heading italic text-white">
                        10,000+ Tons
                      </h4>
                      <p className="text-xs text-white/60 font-light mt-2 font-body">
                        Delivered Monthly Across Houston Metro
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Trust strip at the bottom of hero: delay 1.4s */}
              <motion.div
                id="about"
                initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.4, ease: "easeOut" }}
                className="w-full flex flex-col items-center gap-6 mt-16"
              >
                <div className="liquid-glass rounded-full px-5 py-1.5 text-xs font-light text-white/80 border border-white/5">
                  Trusted by contractors and builders across the Houston Metro Area
                </div>
                <div className="w-full overflow-hidden py-2 border-y border-white/5 bg-black/10 backdrop-blur-xs font-body">
                  <div className="flex flex-wrap justify-center items-center gap-x-8 gap-y-3 md:gap-x-16 text-white text-lg md:text-xl lg:text-2xl font-heading italic tracking-tight">
                    <span>Licensed & Insured</span>
                    <span className="text-white/20 font-sans font-light text-sm">·</span>
                    <span>Locally Owned</span>
                    <span className="text-white/20 font-sans font-light text-sm">·</span>
                    <span>DOT-Certified Fleet</span>
                    <span className="text-white/20 font-sans font-light text-sm">·</span>
                    <span>20+ Years Experience</span>
                  </div>
                </div>
              </motion.div>
            </section>

            {/* MATERIALS */}
            <section
              id="materials"
              className="relative z-10 min-h-screen px-4 md:px-8 lg:px-16 py-32 max-w-7xl mx-auto flex flex-col justify-between border-t border-white/5"
            >
              <div className="mb-16 md:mb-20 text-left max-w-3xl">
                <span className="text-sm font-mono text-white/50 tracking-widest block mb-4 uppercase">
                  // What We Supply
                </span>
                <h2 className="font-heading italic text-white text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[0.95] tracking-[-3px]">
                  Materials That<br />Build Everything
                </h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch mt-8 font-body">
                {/* Card 1: Premium Sand */}
                <div className="liquid-glass rounded-[1.25rem] p-6 min-h-[380px] flex flex-col justify-between group hover:bg-white/[0.02] transition-all duration-500">
                  <div className="flex items-start justify-between gap-4">
                    <div className="w-11 h-11 rounded-[0.75rem] liquid-glass flex items-center justify-center text-white shrink-0">
                      <Mountain className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex flex-wrap justify-end gap-1.5 max-w-[70%]">
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Washed Sand</span>
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Fill Sand</span>
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Masonry Sand</span>
                    </div>
                  </div>
                  <div className="flex-1" />
                  <div className="mt-8 text-left">
                    <h3 className="font-heading italic text-white text-3xl md:text-4xl tracking-[-1px] leading-none">
                      Premium Sand
                    </h3>
                    <p className="mt-3 text-sm text-white/70 font-light leading-relaxed max-w-[32ch]">
                      Clean, screened sand for concrete, masonry, and landscaping — consistent grade, every load.
                    </p>
                    <button 
                      onClick={() => {
                        setSelectedMaterial("Washed Sand");
                        setIsQuoteOpen(true);
                      }}
                      className="mt-4 text-xs font-semibold uppercase tracking-wider text-white flex items-center gap-1 group-hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                      Estimate Pricing <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </button>
                  </div>
                </div>

                {/* Card 2: Crushed Gravel & Stone */}
                <div className="liquid-glass rounded-[1.25rem] p-6 min-h-[380px] flex flex-col justify-between group hover:bg-white/[0.02] transition-all duration-500">
                  <div className="flex items-start justify-between gap-4">
                    <div className="w-11 h-11 rounded-[0.75rem] liquid-glass flex items-center justify-center text-white shrink-0">
                      <Layers className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex flex-wrap justify-end gap-1.5 max-w-[70%]">
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">3/4" Clean Stone</span>
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Pea Gravel</span>
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Road Base</span>
                    </div>
                  </div>
                  <div className="flex-1" />
                  <div className="mt-8 text-left">
                    <h3 className="font-heading italic text-white text-3xl md:text-4xl tracking-[-1px] leading-none">
                      Crushed Gravel & Stone
                    </h3>
                    <p className="mt-3 text-sm text-white/70 font-light leading-relaxed max-w-[32ch]">
                      From road base to decorative stone, our gravel is crushed and graded to spec for any project size.
                    </p>
                    <button 
                      onClick={() => {
                        setSelectedMaterial("3/4\" Clean Stone");
                        setIsQuoteOpen(true);
                      }}
                      className="mt-4 text-xs font-semibold uppercase tracking-wider text-white flex items-center gap-1 group-hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                      Estimate Pricing <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </button>
                  </div>
                </div>

                {/* Card 3: Bulk Delivery */}
                <div className="liquid-glass rounded-[1.25rem] p-6 min-h-[380px] flex flex-col justify-between group hover:bg-white/[0.02] transition-all duration-500">
                  <div className="flex items-start justify-between gap-4">
                    <div className="w-11 h-11 rounded-[0.75rem] liquid-glass flex items-center justify-center text-white shrink-0">
                      <Truck className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex flex-wrap justify-end gap-1.5 max-w-[70%]">
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Same-Day Dispatch</span>
                      <span className="liquid-glass rounded-full px-2.5 py-1 text-[11px] text-white/80 font-light">Site Drop-Off</span>
                    </div>
                  </div>
                  <div className="flex-1" />
                  <div className="mt-8 text-left">
                    <h3 className="font-heading italic text-white text-3xl md:text-4xl tracking-[-1px] leading-none">
                      Bulk Delivery
                    </h3>
                    <p className="mt-3 text-sm text-white/70 font-light leading-relaxed max-w-[32ch]">
                      Order by the ton or the truckload. We dispatch fast and deliver straight to your residential or commercial job site.
                    </p>
                    <button 
                      onClick={() => {
                        setActiveTab('order');
                        setTimeout(() => {
                          const el = document.getElementById("order-section");
                          if (el) el.scrollIntoView({ behavior: "smooth" });
                        }, 100);
                      }}
                      className="mt-4 text-xs font-semibold uppercase tracking-wider text-white flex items-center gap-1 group-hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                      Estimate Delivery <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* CLOSING QUOTE BAND */}
            <section
              id="quote-band"
              className="relative z-10 px-4 md:px-8 py-24 max-w-7xl mx-auto"
            >
              <div className="liquid-glass-strong rounded-[2rem] p-8 md:p-16 flex flex-col md:flex-row items-center justify-between gap-8 border border-white/5 bg-black/40 backdrop-blur-xl">
                <div className="text-left flex-1">
                  <h3 className="font-heading italic text-white text-4xl md:text-5xl lg:text-6xl tracking-[-2px] leading-tight">
                    Ready To Order?
                  </h3>
                  <p className="text-white/70 font-light mt-3 max-w-md leading-relaxed text-sm md:text-base font-body">
                    Tell us what you need and where — we'll calculate your aggregate quantities, get you a final quote, and lock in a delivery window today.
                  </p>
                </div>

                <div className="flex flex-col gap-4 items-stretch md:items-end w-full md:w-auto shrink-0 font-body">
                  <button
                    onClick={() => setActiveTab('order')}
                    className="bg-white text-black hover:bg-white/90 font-medium px-8 py-4 text-sm md:text-base rounded-full flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap shadow-lg font-semibold"
                  >
                    Place an Order <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                  </button>
                  <span className="text-[11px] text-white/40 uppercase tracking-wider font-mono text-center md:text-right">
                    No Obligation · Fully Detailed Estimates
                  </span>
                </div>
              </div>
            </section>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-white/5 bg-black/95 py-12 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full liquid-glass flex items-center justify-center font-heading italic text-lg font-bold">
              t
            </div>
            <span className="font-heading italic text-xl tracking-tight text-white/90">Thatamarketing</span>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-4 text-xs text-white/40 font-mono">
            <span>&copy; 2026 ThataMarketing Construction Supplies. All Rights Reserved.</span>
            <span>·</span>
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span>·</span>
            <button
              onClick={() => setIsTermsOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Terms & Conditions
            </button>
            <span>·</span>
            <button
              onClick={() => {
                if (activeTab === 'order') {
                  const el = document.getElementById("order-hero");
                  if (el) el.scrollIntoView({ behavior: "smooth" });
                } else {
                  const el = document.getElementById("hero");
                  if (el) el.scrollIntoView({ behavior: "smooth" });
                }
              }}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Back to Top
            </button>
          </div>
        </div>
      </footer>

      {/* ORIGINAL INTERACTIVE ESTIMATOR SLIDE-OVER DRAWER (For Marketing page) */}
      <AnimatePresence>
        {isQuoteOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden font-body">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsQuoteOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            {/* Slide over */}
            <div className="absolute inset-y-0 right-0 max-w-full flex">
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="w-screen max-w-lg"
              >
                <div className="h-full flex flex-col bg-neutral-950/95 border-l border-white/10 shadow-2xl relative overflow-hidden liquid-glass-strong">
                  
                  {/* Drawer Header */}
                  <div className="px-6 py-6 border-b border-white/10 flex items-center justify-between bg-black/40">
                    <div className="text-left">
                      <h2 className="text-2xl font-heading italic text-white tracking-wide">
                        Material & Delivery Order
                      </h2>
                      <p className="text-xs text-white/60 font-light mt-1">
                        Get instant transparent pricing and place your order.
                      </p>
                    </div>
                    <button
                      onClick={() => setIsQuoteOpen(false)}
                      className="p-2 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Drawer Content */}
                  <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
                    <AnimatePresence mode="wait">
                      {!isSubmitted ? (
                        <motion.form
                          key="quote-form"
                          onSubmit={handleSubmitQuote}
                          className="space-y-6 text-left"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                        >
                          {/* Aggregate Selector */}
                          <div className="space-y-2">
                            <label className="text-xs font-mono uppercase tracking-wider text-white/50 block">
                              1. Select Aggregate Material
                            </label>
                            <div className="grid grid-cols-2 gap-2">
                              {Object.keys(MATERIAL_PRICES).map((mat) => (
                                <button
                                  key={mat}
                                  type="button"
                                  onClick={() => setSelectedMaterial(mat)}
                                  className={`p-3 rounded-xl text-left border transition-all text-xs flex flex-col justify-between ${
                                    selectedMaterial === mat
                                      ? "border-white bg-white/10 text-white font-semibold"
                                      : "border-white/5 bg-white/[0.01] text-white/60 hover:border-white/20 hover:text-white"
                                  } cursor-pointer`}
                                >
                                  <span>{mat}</span>
                                  <span className="text-[10px] text-white/40 mt-1">${MATERIAL_PRICES[mat]}/ton</span>
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Tonnage Slider */}
                          <div className="space-y-3 bg-white/[0.02] p-4 rounded-2xl border border-white/5">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-mono uppercase tracking-wider text-white/50">
                                2. Aggregate Tonnage
                              </label>
                              <span className="text-lg font-heading italic text-white font-semibold">
                                {tonnage} Tons
                              </span>
                            </div>
                            <input
                              type="range"
                              min="5"
                              max="150"
                              step="5"
                              value={tonnage}
                              onChange={(e) => setTonnage(Number(e.target.value))}
                              className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-white"
                            />
                            <div className="flex justify-between text-[10px] text-white/30 font-mono">
                              <span>5 Tons (Min)</span>
                              <span>75 Tons</span>
                              <span>150 Tons (Max)</span>
                            </div>
                          </div>

                          {/* Instant Price Summary Block */}
                          <div className="bg-white/5 p-5 rounded-2xl border border-white/10 relative overflow-hidden space-y-3">
                            <div className="absolute top-0 right-0 p-1 bg-white/10 rounded-bl-xl">
                              <span className="text-[9px] uppercase font-mono tracking-wider text-white/60 px-2 py-0.5">Live Estimate</span>
                            </div>

                            <div className="text-xs text-white/50 space-y-1.5">
                              <div className="flex justify-between">
                                <span>{selectedMaterial} Aggregate ({tonnage} tons)</span>
                                <span className="text-white">${materialsSubtotal.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Flat Dispatch Delivery Fee</span>
                                <span className="text-white">${flatDeliveryFee.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Estimated Tax (8.25%)</span>
                                <span className="text-white">${estimatedTax.toLocaleString()}</span>
                              </div>
                            </div>

                            <div className="border-t border-white/10 pt-3 flex justify-between items-end">
                              <span className="text-xs font-mono uppercase tracking-wider text-white/50">Estimated Total Cost</span>
                              <span className="text-2xl font-heading italic text-white font-semibold leading-none">
                                ${totalCost.toLocaleString()}
                              </span>
                            </div>

                            <div className="flex items-center gap-2 text-[11px] text-white/40 mt-1">
                              <Info className="w-3.5 h-3.5 shrink-0" />
                              <span>Custom discounts are automatically calculated for requests over 50 tons.</span>
                            </div>
                          </div>

                          {/* Contact Details */}
                          <div className="space-y-4">
                            <label className="text-xs font-mono uppercase tracking-wider text-white/50 block">
                              3. Delivery & Contact Details
                            </label>
                            
                            <div className="space-y-3">
                              <input
                                type="text"
                                placeholder="Full Name *"
                                required
                                value={fullName}
                                onChange={(e) => setFullName(e.target.value)}
                                className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:border-white focus:outline-none transition-colors"
                              />

                              <div className="grid grid-cols-2 gap-2">
                                <input
                                  type="tel"
                                  placeholder="Phone Number *"
                                  required
                                  value={phone}
                                  onChange={(e) => setPhone(e.target.value)}
                                  className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:border-white focus:outline-none transition-colors"
                                />
                                <input
                                  type="email"
                                  placeholder="Email Address *"
                                  required
                                  value={email}
                                  onChange={(e) => setEmail(e.target.value)}
                                  className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:border-white focus:outline-none transition-colors"
                                />
                              </div>

                              <input
                                type="text"
                                placeholder="Delivery Address (Houston Metro Area) *"
                                required
                                value={deliveryAddress}
                                onChange={(e) => setDeliveryAddress(e.target.value)}
                                className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:border-white focus:outline-none transition-colors"
                              />

                              <input
                                type="date"
                                placeholder="Preferred Delivery Date"
                                value={deliveryDate}
                                onChange={(e) => setDeliveryDate(e.target.value)}
                                className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-white focus:outline-none transition-colors"
                              />
                            </div>
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-white text-black hover:bg-white/90 font-semibold py-4 rounded-xl text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-98"
                          >
                            Submit Dispatch Order <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                          </button>
                        </motion.form>
                      ) : (
                        /* Success Panel */
                        <motion.div
                          key="success-form"
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className="h-full flex flex-col items-center justify-center text-center px-4 py-16 space-y-6"
                        >
                          <div className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center shadow-2xl animate-bounce">
                            <Check className="w-8 h-8 stroke-[3]" />
                          </div>
                          
                          <div className="space-y-2">
                            <h3 className="text-3xl font-heading italic text-white">
                              Order Submitted!
                            </h3>
                            <p className="text-sm text-white/70 font-light max-w-xs mx-auto leading-relaxed">
                              Thank you, <strong>{fullName}</strong>. Your order of <strong>${totalCost.toLocaleString()}</strong> has been registered with our dispatch team.
                            </p>
                          </div>

                          <div className="bg-white/5 p-4 rounded-xl border border-white/10 w-full max-w-sm text-left space-y-2 text-xs font-mono text-white/60">
                            <div className="flex justify-between">
                              <span>Ticket ID:</span>
                              <span className="text-white">THATA-{Math.floor(100000 + Math.random() * 900000)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Material:</span>
                              <span className="text-white">{selectedMaterial} ({tonnage} Tons)</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Location:</span>
                              <span className="text-white truncate max-w-[180px]">{deliveryAddress}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Status:</span>
                              <span className="text-white bg-white/10 px-1.5 py-0.5 rounded text-[10px] uppercase font-bold text-yellow-400">Awaiting Call</span>
                            </div>
                          </div>

                          <p className="text-[11px] text-white/40 leading-snug max-w-xs">
                            A certified aggregate logistics specialist will call you at <strong>{phone}</strong> within 15 minutes to lock in dispatch and delivery details.
                          </p>

                          <button
                            onClick={handleResetForm}
                            className="liquid-glass hover:bg-white/5 text-white font-medium px-6 py-2.5 rounded-full text-xs transition-colors cursor-pointer"
                          >
                            Close Drawer
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                </div>
              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* FULL SCREEN VIDEO PLAYER MODAL */}
      <AnimatePresence>
        {isVideoModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsVideoModalOpen(false)}
              className="absolute inset-0 bg-black/95 backdrop-blur-lg cursor-pointer"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-5xl aspect-video bg-neutral-900 rounded-2xl overflow-hidden shadow-2xl border border-white/10"
            >
              <button
                onClick={() => setIsVideoModalOpen(false)}
                className="absolute top-4 right-4 p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white/80 hover:text-white transition-colors z-10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <iframe
                src={`${BG_VIDEO_URL}#t=0.1`}
                className="w-full h-full object-cover"
                title="Thatamarketing Drone Video"
                allow="autoplay"
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SELECTED ITEMS FLOATING SUMMARY BAR */}
      <AnimatePresence>
        {selectedCount > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 20, x: "-50%" }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[140] px-4 w-full max-w-lg"
          >
            <div className="liquid-glass-strong rounded-2xl px-5 py-3 flex items-center justify-between gap-4">
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-sm font-body font-semibold text-white">
                  {selectedCount} item{selectedCount > 1 ? 's' : ''} selected
                </span>
                <span className="text-xs text-white/50 font-body mt-0.5 truncate max-w-[200px] block">
                  {selectedTotal}
                </span>
              </div>
              <button
                onClick={() => {
                  const el = document.getElementById('details-form') || document.getElementById('order-section');
                  if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }
                }}
                className="liquid-glass rounded-full px-4 py-2 text-xs font-body font-semibold text-white cursor-pointer whitespace-nowrap shrink-0 hover:bg-white/10 transition-colors"
              >
                View Order →
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FLOATING TALK BUTTON */}
      <div className="fixed bottom-6 right-6 z-[150] flex flex-col items-center gap-1.5">
        <div className="relative w-16 h-16">
          {callStatus !== 'idle' && callStatus !== 'filled' && (
            <div className="absolute inset-[-6px] rounded-full border border-white/20 bg-white/5 pulse-ring z-0" />
          )}
          <button
            onClick={() => {
              setIsTalkOpen(true);
            }}
            className="w-16 h-16 liquid-glass-strong rounded-full flex items-center justify-center cursor-pointer z-10 relative hover:scale-105 active:scale-95 transition-transform"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-6 h-6">
              <rect x="9" y="2" width="6" height="11" rx="3"/>
              <path d="M5 10a7 7 0 0 0 14 0M12 19v3M8 22h8" strokeLinecap="round"/>
            </svg>
          </button>
        </div>
        <div className="liquid-glass rounded-full px-3 py-1 text-[10px] font-body font-semibold text-white tracking-widest shadow-md">
          {callStatus === 'idle' || callStatus === 'filled' ? (
            "TALK"
          ) : (
            <span className="text-green-300">LIVE</span>
          )}
        </div>
      </div>

      {isTalkOpen && (
        <TalkModal
          isOpen={isTalkOpen}
          callStatus={callStatus}
          stopCall={stopCall}
          callError={callError}
          startCall={startCall}
        />
      )}

      {/* PRIVACY POLICY MODAL */}
      <AnimatePresence>
        {isPrivacyOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 overflow-hidden">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPrivacyOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
            />
            
            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative w-full max-w-2xl max-h-[85vh] liquid-glass-strong border border-white/10 rounded-2xl bg-neutral-950/90 shadow-2xl z-10 flex flex-col font-body overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/10 p-6 md:px-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white shrink-0">
                    <Info className="w-5 h-5 text-white/95" />
                  </div>
                  <div className="text-left">
                    <h2 className="text-xl md:text-2xl font-heading italic text-white font-semibold">Privacy Policy</h2>
                    <p className="text-[10px] text-white/40 font-mono tracking-wider uppercase mt-0.5">Last updated: June 2026</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPrivacyOpen(false)}
                  className="p-2 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors cursor-pointer"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 text-sm text-white/80 leading-relaxed font-light text-left">
                <p>At <strong>ThataMarketing Construction Supplies</strong>, we are fully committed to protecting your privacy and ensuring the security of your personal data. This Privacy Policy details how we collect, use, process, and safeguard the information you share with us in accordance with the Data Privacy Act of 2012 (Republic Act No. 10173) of the Philippines.</p>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">1. Information We Collect</h3>
                  <p>To process your orders, arrange logistical dispatch, and provide premium customer service, we collect only the necessary information, which includes:</p>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li><strong>Full Name</strong> (for customer registry and delivery documentation)</li>
                    <li><strong>Mobile Number</strong> (for order confirmations and delivery coordination)</li>
                    <li><strong>Delivery Address</strong> (to calculate transit route, freight costs, and navigate drop-offs)</li>
                    <li><strong>Ordered Products &amp; Quantities</strong> (for material dispatch and inventory control)</li>
                    <li><strong>Order Notes</strong> (for specific site instructions and custom specifications)</li>
                    <li><strong>Voice Conversation Details</strong> (provided through our smart AI assistant to accurately capture and transcribe order requests)</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">2. How We Use Your Information</h3>
                  <p>The personal data we collect is utilized exclusively for the following business purposes:</p>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>Processing and registering your material purchase orders.</li>
                    <li>Arranging direct deliveries to your specified project site or depot.</li>
                    <li>Contacting you with real-time updates regarding pricing, availability, and transit schedules.</li>
                    <li>Improving customer experience, resolving dispatch inquiries, and refining our AI voice ordering assistant.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">3. Data Sharing and Protection</h3>
                  <p>We implement strict security measures to protect your information:</p>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li><strong>No Commercial Sale:</strong> ThataMarketing Construction Supplies will never sell, lease, rent, or trade your personal data to third parties.</li>
                    <li><strong>Secure Transmission:</strong> Your order details are securely transmitted to our internal business systems, database management networks, and dispatch workflows to fulfill logistics seamlessly.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">4. Your Rights &amp; Contacts</h3>
                  <p>Under the Philippine Data Privacy Act, you have the right to access, correct, update, or request the deletion of your personal data. For any questions, modifications, or concerns regarding your information, please contact our team at:</p>
                  <div className="bg-white/5 border border-white/5 rounded-xl p-4 font-mono text-xs text-white/70 space-y-1">
                    <p>Email: hallegadoprincejohnver@gmail.com</p>
                    <p>Support: ThataMarketing Construction Supplies Dispatch &amp; Support</p>
                  </div>
                </div>
              </div>

              {/* Footer Button */}
              <div className="border-t border-white/10 p-4 md:px-8 bg-black/40 flex justify-end">
                <button
                  onClick={() => setIsPrivacyOpen(false)}
                  className="bg-white text-black hover:bg-white/90 font-medium px-6 py-2 rounded-full text-xs transition-all active:scale-95 cursor-pointer shadow-md"
                >
                  Close Window
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TERMS & CONDITIONS MODAL */}
      <AnimatePresence>
        {isTermsOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 overflow-hidden">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsTermsOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
            />
            
            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative w-full max-w-2xl max-h-[85vh] liquid-glass-strong border border-white/10 rounded-2xl bg-neutral-950/90 shadow-2xl z-10 flex flex-col font-body overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/10 p-6 md:px-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white shrink-0">
                    <Info className="w-5 h-5 text-white/95" />
                  </div>
                  <div className="text-left">
                    <h2 className="text-xl md:text-2xl font-heading italic text-white font-semibold">Terms &amp; Conditions</h2>
                    <p className="text-[10px] text-white/40 font-mono tracking-wider uppercase mt-0.5">Last updated: June 2026</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsTermsOpen(false)}
                  className="p-2 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors cursor-pointer"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 text-sm text-white/80 leading-relaxed font-light text-left">
                <p>Welcome to <strong>ThataMarketing Construction Supplies</strong>. By accessing our services, submitting purchase requests, or interacting with our AI order assistant, you agree to comply with and be bound by the following Terms &amp; Conditions. Please read them carefully before confirming any orders.</p>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">1. Order Confirmation &amp; Stock Availability</h3>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>All orders submitted through our web portal or voice assistant are subject to final confirmation and verification by our dispatch team.</li>
                    <li>All material listings, including sand, stone, and building products, are subject to stock availability at the time of loading.</li>
                    <li>Product specifications, designs, and availability may change or be discontinued without prior notice.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">2. Pricing &amp; Quotations</h3>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>All published prices are indicative and subject to change without prior notice due to fluctuations in raw material costs, logistics, and fuel rates.</li>
                    <li>A final detailed quotation (including transit/freight charges if applicable) will be presented and must be confirmed before processing the order.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">3. Delivery Logistics &amp; Drop-Off</h3>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>Delivery schedules are arranged in good faith, but physical dispatch times depend heavily on local weather conditions, road closures, traffic, and queuing at the quarry/warehouse.</li>
                    <li>Any stated delivery times are estimates only. ThataMarketing is not liable for indirect losses caused by delayed delivery.</li>
                    <li>Customers are solely responsible for providing an accurate delivery address and ensuring safe, unobstructed site access for dump trucks or delivery vehicles.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">4. Customer Responsibilities</h3>
                  <p>To ensure a flawless fulfillment process, you agree to provide:</p>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>Accurate and working contact information (name, mobile number, active email).</li>
                    <li>Correct and precise delivery site coordinates and access directions.</li>
                    <li>Accurate quantities. Excess or short materials resulting from incorrect measurements provided by the customer are the customer's responsibility.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">5. Order Cancellations &amp; Modifications</h3>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>Orders may be modified or cancelled without penalty before they are dispatched or loaded onto trucks.</li>
                    <li>Once a vehicle has left our depot, cancellations or address re-routing will be subject to transport surcharge fees.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-white font-semibold text-base">6. Force Majeure &amp; Limitation of Liability</h3>
                  <p>The company shall not be held liable or responsible for delayed performance or non-delivery resulting from events beyond our reasonable control, including but not limited to:</p>
                  <ul className="list-disc pl-5 space-y-1.5 text-white/70">
                    <li>Inclement weather, typhoons, flooding, and natural disasters.</li>
                    <li>Road closures, infrastructure damage, and heavy highway traffic.</li>
                    <li>Mechanical vehicle breakdowns, transit accidents, or quarry/warehouse operational halts.</li>
                  </ul>
                </div>
              </div>

              {/* Footer Button */}
              <div className="border-t border-white/10 p-4 md:px-8 bg-black/40 flex justify-end">
                <button
                  onClick={() => setIsTermsOpen(false)}
                  className="bg-white text-black hover:bg-white/90 font-medium px-6 py-2 rounded-full text-xs transition-all active:scale-95 cursor-pointer shadow-md"
                >
                  Close Window
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
