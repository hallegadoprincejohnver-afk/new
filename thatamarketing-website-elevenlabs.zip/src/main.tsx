import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

if (typeof window !== "undefined") {
  // Intercept console.error and console.warn to filter out permission policy errors
  const originalConsoleError = console.error;
  console.error = function (...args) {
    const argStr = args.map(arg => String(arg)).join(" ");
    if (
      argStr.includes("permissions-policy") ||
      argStr.includes("permissions policy") ||
      argStr.includes("Permissions policy") ||
      argStr.includes("Permissions Policy") ||
      argStr.includes("potential-permissions-policy-violation")
    ) {
      return;
    }
    return originalConsoleError.apply(console, args);
  };

  const originalConsoleWarn = console.warn;
  console.warn = function (...args) {
    const argStr = args.map(arg => String(arg)).join(" ");
    if (
      argStr.includes("permissions-policy") ||
      argStr.includes("permissions policy") ||
      argStr.includes("Permissions policy") ||
      argStr.includes("Permissions Policy") ||
      argStr.includes("potential-permissions-policy-violation")
    ) {
      return;
    }
    return originalConsoleWarn.apply(console, args);
  };

  // Intercept ReportingObserver to filter out permissions-policy-violation reports
  if ((window as any).ReportingObserver) {
    const OriginalReportingObserver = (window as any).ReportingObserver;
    (window as any).ReportingObserver = function (callback: any, options: any) {
      const wrappedCallback = (reports: any[], observerInstance: any) => {
        const filteredReports = reports.filter((report) => {
          const type = report.type;
          const bodyStr = JSON.stringify(report.body || {});
          if (
            type === "permissions-policy-violation" ||
            bodyStr.includes("permissions-policy") ||
            bodyStr.includes("permissions policy") ||
            bodyStr.includes("potential-permissions-policy-violation")
          ) {
            return false;
          }
          return true;
        });
        if (filteredReports.length > 0) {
          callback(filteredReports, observerInstance);
        }
      };
      return new OriginalReportingObserver(wrappedCallback, options);
    };
    (window as any).ReportingObserver.prototype = OriginalReportingObserver.prototype;
  }

  // Catch and suppress cross-origin script errors (such as Cloudflare Turnstile iframes blocking or failing)
  const originalOnError = window.onerror;
  window.onerror = function (message, source, lineno, colno, error) {
    const msgStr = String(message);
    if (
      msgStr.includes("Script error") ||
      msgStr.includes("turnstile") ||
      msgStr.includes("permissions-policy") ||
      msgStr.includes("permissions policy") ||
      msgStr.includes("Permissions policy") ||
      msgStr.includes("Permissions Policy") ||
      (source && source.includes("challenges.cloudflare.com"))
    ) {
      console.warn("Suppressed global script/policy warning:", message, "from source:", source);
      return true; // Suppress error propagation
    }
    if (originalOnError) {
      return originalOnError.apply(this, [message, source, lineno, colno, error]);
    }
    return false;
  };

  window.addEventListener("error", (event) => {
    const msgStr = String(event.message);
    if (
      msgStr.includes("Script error") ||
      msgStr.includes("turnstile") ||
      msgStr.includes("permissions-policy") ||
      msgStr.includes("permissions policy") ||
      msgStr.includes("Permissions policy") ||
      msgStr.includes("Permissions Policy") ||
      (event.filename && event.filename.includes("challenges.cloudflare.com"))
    ) {
      console.warn("Caught and prevented default for error/policy warning:", event.message);
      event.preventDefault();
    }
  }, true);

  window.addEventListener("unhandledrejection", (event) => {
    const reason = event.reason;
    if (reason) {
      const reasonStr = String(reason.message || reason);
      if (
        reasonStr.includes("turnstile") || 
        reasonStr.includes("permissions-policy") ||
        reasonStr.includes("permissions policy") ||
        reasonStr.includes("Permissions policy") ||
        reasonStr.includes("Permissions Policy") ||
        (reason.stack && reason.stack.includes("turnstile"))
      ) {
        console.warn("Caught and prevented default for unhandled rejection/policy warning:", reasonStr);
        event.preventDefault();
      }
    }
  }, true);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

